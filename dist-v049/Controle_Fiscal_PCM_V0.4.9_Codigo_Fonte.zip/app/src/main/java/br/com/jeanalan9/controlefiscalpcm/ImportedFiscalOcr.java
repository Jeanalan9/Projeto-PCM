package br.com.jeanalan9.controlefiscalpcm;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.graphics.pdf.PdfRenderer;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.InputStream;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * OCR local e assíncrono para complementar dados de DANFSe/NFS-e importadas.
 *
 * A leitura do QR/código de barras continua sendo a primeira etapa. Este OCR é
 * executado somente como enriquecimento e não bloqueia o retorno do código ao usuário.
 */
public final class ImportedFiscalOcr {
    private static final Pattern DATE = Pattern.compile("(?<!\\d)([0-3]?\\d/[01]?\\d/(?:19|20)\\d{2})(?:\\s+[0-2]?\\d:[0-5]\\d(?::[0-5]\\d)?)?");
    private static final Pattern MONEY = Pattern.compile("(?i)(?:R\\$\\s*)?([0-9]{1,3}(?:\\.[0-9]{3})*,[0-9]{2}|[0-9]+,[0-9]{2})");
    private static final Pattern CNPJ = Pattern.compile("(?<!\\d)(\\d{2}\\.?\\d{3}\\.?\\d{3}/?\\d{4}-?\\d{2})(?!\\d)");
    private static final Pattern CPF = Pattern.compile("(?<!\\d)(\\d{3}\\.?\\d{3}\\.?\\d{3}-?\\d{2})(?!\\d)");
    private static final Pattern NUMBER_AFTER_NFSE = Pattern.compile("(?i)(?:N[ÚU]MERO\\s+DA\\s+NFS[- ]?E|NFS[- ]?E\\s*(?:N[º°O]|NUMERO)?)\\s*[:#-]?\\s*(\\d{1,15})");

    private final Context context;

    public ImportedFiscalOcr(Context context) {
        this.context = context.getApplicationContext();
    }

    public JSONObject recognize(Uri uri, String knownCnpj, String knownNumber) throws Exception {
        Bitmap bitmap = null;
        TextRecognizer recognizer = null;
        try {
            bitmap = loadFirstPage(uri, 2200);
            if (bitmap == null) throw new IllegalArgumentException("Não foi possível preparar o documento para leitura local.");

            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            Text text = Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0)), 18, TimeUnit.SECONDS);
            if (text == null || text.getText() == null || text.getText().trim().isEmpty()) {
                throw new IllegalArgumentException("O documento não contém texto legível suficiente para completar a NFS-e.");
            }

            List<LineInfo> lines = flatten(text);
            String rawText = text.getText();
            JSONObject out = parse(rawText, lines, knownCnpj, knownNumber);
            out.put("fonte", "leitura local do documento");
            out.put("tipoDocumento", "NFS-e");
            out.put("diagnostico", "ORDEM_SERVICO");
            return out;
        } finally {
            if (recognizer != null) try { recognizer.close(); } catch (Exception ignored) {}
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private JSONObject parse(String raw, List<LineInfo> lines, String knownCnpj, String knownNumber) throws Exception {
        JSONObject out = new JSONObject();
        String fornecedor = findProvider(lines);
        String emissao = findDate(lines, raw);
        String valor = findValue(lines, raw);
        String cnpj = cleanDigits(knownCnpj);
        if (cnpj.length() != 14 && cnpj.length() != 11) cnpj = findTaxId(lines, raw);
        String numero = knownNumber == null ? "" : knownNumber.replaceAll("\\D", "");
        if (numero.isEmpty()) numero = findNumber(raw);

        boolean serviceLike = containsAny(norm(raw), "NFS-E", "NFSE", "NOTA FISCAL DE SERVICO", "DOCUMENTO AUXILIAR DA NFS", "SERVICO PRESTADO", "PRESTADOR / FORNECEDOR", "PRESTADOR DE SERVICOS");
        int recovered = 0;
        if (!fornecedor.isEmpty()) { out.put("fornecedor", fornecedor); recovered++; }
        if (!cnpj.isEmpty()) { out.put("cnpj", formatTaxId(cnpj)); recovered++; }
        if (!emissao.isEmpty()) { out.put("emissao", emissao); recovered++; }
        if (!valor.isEmpty()) { out.put("valor", valor); recovered++; }
        if (!numero.isEmpty()) out.put("numero", numero);
        out.put("ok", serviceLike && recovered >= 2);
        out.put("completo", !fornecedor.isEmpty() && !emissao.isEmpty() && !valor.isEmpty());
        out.put("camposRecuperados", recovered);
        return out;
    }

    private static String findProvider(List<LineInfo> lines) {
        int providerSection = -1;
        int endSection = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            String n = norm(lines.get(i).text);
            if (providerSection < 0 && containsAny(n, "PRESTADOR / FORNECEDOR", "PRESTADOR DE SERVICOS", "PRESTADOR DO SERVICO", "EMITENTE DA NFS")) {
                providerSection = i;
            } else if (providerSection >= 0 && containsAny(n, "TOMADOR / ADQUIRENTE", "TOMADOR DE SERVICOS", "TOMADOR DO SERVICO", "SERVICO PRESTADO")) {
                endSection = i;
                break;
            }
        }
        int start = providerSection >= 0 ? providerSection : 0;
        int end = providerSection >= 0 ? endSection : Math.min(lines.size(), 45);

        // Prioriza o conteúdo imediatamente abaixo de Nome/Nome Empresarial ou Razão Social.
        for (int i = start; i < end; i++) {
            String original = lines.get(i).text.trim();
            String n = norm(original);
            if (containsAny(n, "NOME / NOME EMPRESARIAL", "NOME/NOME EMPRESARIAL", "NOME EMPRESARIAL", "RAZAO SOCIAL", "NOME DO PRESTADOR")) {
                String inline = afterLabel(original);
                if (isProviderCandidate(inline)) return cleanProvider(inline);
                for (int j = i + 1; j < Math.min(end, i + 5); j++) {
                    String candidate = lines.get(j).text.trim();
                    if (isProviderCandidate(candidate)) return cleanProvider(candidate);
                }
            }
        }

        // Fallback dentro da seção do prestador: procura uma linha textual forte que não seja rótulo/endereço.
        if (providerSection >= 0) {
            for (int i = providerSection + 1; i < Math.min(end, providerSection + 14); i++) {
                String candidate = lines.get(i).text.trim();
                if (isProviderCandidate(candidate)) return cleanProvider(candidate);
            }
        }
        return "";
    }

    private static boolean isProviderCandidate(String value) {
        if (value == null) return false;
        String s = value.trim();
        if (s.length() < 4 || s.length() > 120) return false;
        String n = norm(s);
        if (!s.matches(".*[A-Za-zÀ-ÿ].*")) return false;
        if (containsAny(n, "NOME", "RAZAO SOCIAL", "CNPJ", "CPF", "NIF", "ENDERECO", "MUNICIPIO", "TELEFONE", "EMAIL", "CODIGO", "PRESTADOR", "FORNECEDOR", "TOMADOR", "INSCRICAO", "SIMPLES NACIONAL", "REGIME", "DATA", "SERVICO PRESTADO", "DOCUMENTO AUXILIAR")) return false;
        if (n.matches(".*\\b(RUA|AVENIDA|ROD|RODOVIA|BAIRRO|CEP|ZONA RURAL)\\b.*")) return false;
        return true;
    }

    private static String cleanProvider(String s) {
        if (s == null) return "";
        return s.replaceAll("^[\\s:;|=-]+", "").replaceAll("[\\s|]+$", "").replaceAll("\\s{2,}", " ").trim();
    }

    private static String findDate(List<LineInfo> lines, String raw) {
        String[] labels = new String[]{"DATA E HORA DA EMISSAO DA NFS", "DATA/HORA DA EMISSAO", "DATA DE EMISSAO", "EMISSAO DA NFS"};
        for (int i = 0; i < lines.size(); i++) {
            String n = norm(lines.get(i).text);
            if (containsAny(n, labels)) {
                String found = firstDate(lines.get(i).text);
                if (!found.isEmpty()) return found;
                for (int j = i + 1; j < Math.min(lines.size(), i + 5); j++) {
                    found = firstDate(lines.get(j).text);
                    if (!found.isEmpty()) return found;
                }
            }
        }
        String normalizedRaw = raw == null ? "" : raw;
        Matcher m = DATE.matcher(normalizedRaw);
        return m.find() ? normalizeDate(m.group(1)) : "";
    }

    private static String firstDate(String s) {
        Matcher m = DATE.matcher(s == null ? "" : s);
        return m.find() ? normalizeDate(m.group(1)) : "";
    }

    private static String normalizeDate(String s) {
        if (s == null) return "";
        String[] p = s.split("/");
        if (p.length != 3) return s;
        try {
            int d = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            int y = Integer.parseInt(p[2]);
            if (d < 1 || d > 31 || m < 1 || m > 12 || y < 2000 || y > 2200) return "";
            return String.format(Locale.US, "%02d/%02d/%04d", d, m, y);
        } catch (Exception e) { return ""; }
    }

    private static String findValue(List<LineInfo> lines, String raw) {
        String[] preferred = new String[]{
                "VALOR TOTAL DA NFS", "VALOR LIQUIDO DA NFS", "VALOR DA OPERACAO / SERVICO",
                "VALOR DA OPERACAO", "VALOR DOS SERVICOS", "VALOR DO SERVICO", "VALOR TOTAL"
        };
        for (String label : preferred) {
            for (int i = 0; i < lines.size(); i++) {
                String n = norm(lines.get(i).text);
                if (!n.contains(label)) continue;
                String value = firstMoney(lines.get(i).text, true);
                if (!value.isEmpty()) return value;
                for (int j = i + 1; j < Math.min(lines.size(), i + 5); j++) {
                    value = firstMoney(lines.get(j).text, true);
                    if (!value.isEmpty()) return value;
                }
            }
        }

        String upper = norm(raw);
        for (String label : preferred) {
            int idx = upper.indexOf(label);
            if (idx >= 0) {
                int end = Math.min(raw.length(), idx + label.length() + 180);
                String value = firstMoney(raw.substring(Math.min(idx, raw.length()), end), true);
                if (!value.isEmpty()) return value;
            }
        }
        return "";
    }

    private static String firstMoney(String s, boolean nonZero) {
        Matcher m = MONEY.matcher(s == null ? "" : s);
        while (m.find()) {
            String numeric = m.group(1);
            String digits = numeric.replace(".", "").replace(",", ".");
            try {
                double v = Double.parseDouble(digits);
                if (nonZero && v <= 0.0001) continue;
                return "R$ " + numeric;
            } catch (Exception ignored) {}
        }
        return "";
    }

    private static String findTaxId(List<LineInfo> lines, String raw) {
        int providerSection = -1;
        int endSection = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            String n = norm(lines.get(i).text);
            if (providerSection < 0 && containsAny(n, "PRESTADOR / FORNECEDOR", "PRESTADOR DE SERVICOS", "EMITENTE DA NFS")) providerSection = i;
            else if (providerSection >= 0 && containsAny(n, "TOMADOR / ADQUIRENTE", "TOMADOR DE SERVICOS", "SERVICO PRESTADO")) { endSection = i; break; }
        }
        if (providerSection >= 0) {
            StringBuilder section = new StringBuilder();
            for (int i = providerSection; i < Math.min(endSection, providerSection + 18); i++) section.append(lines.get(i).text).append('\n');
            String id = findTaxId(section.toString());
            if (!id.isEmpty()) return id;
        }
        return findTaxId(raw);
    }

    private static String findTaxId(String text) {
        Matcher c = CNPJ.matcher(text == null ? "" : text);
        if (c.find()) return cleanDigits(c.group(1));
        Matcher f = CPF.matcher(text == null ? "" : text);
        if (f.find()) return cleanDigits(f.group(1));
        return "";
    }

    private static String findNumber(String raw) {
        Matcher m = NUMBER_AFTER_NFSE.matcher(raw == null ? "" : raw);
        if (m.find()) return m.group(1).replaceFirst("^0+(?!$)", "");
        return "";
    }

    private static String afterLabel(String line) {
        if (line == null) return "";
        int idx = line.indexOf(':');
        if (idx >= 0 && idx < line.length() - 1) return line.substring(idx + 1).trim();
        return "";
    }

    private static String cleanDigits(String s) { return s == null ? "" : s.replaceAll("\\D", ""); }

    private static String formatTaxId(String d) {
        if (d == null) return "";
        if (d.length() == 14) return d.substring(0,2)+"."+d.substring(2,5)+"."+d.substring(5,8)+"/"+d.substring(8,12)+"-"+d.substring(12);
        if (d.length() == 11) return d.substring(0,3)+"."+d.substring(3,6)+"."+d.substring(6,9)+"-"+d.substring(9);
        return d;
    }

    private static String norm(String s) {
        String n = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.toUpperCase(Locale.ROOT).replace('–','-').replace('—','-').replaceAll("\\s+", " ").trim();
    }

    private static boolean containsAny(String text, String... values) {
        if (text == null) return false;
        for (String v : values) if (v != null && !v.isEmpty() && text.contains(v)) return true;
        return false;
    }

    private static List<LineInfo> flatten(Text text) {
        List<LineInfo> out = new ArrayList<>();
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String s = line.getText();
                if (s == null || s.trim().isEmpty()) continue;
                Rect r = line.getBoundingBox();
                out.add(new LineInfo(s.trim(), r));
            }
        }
        out.sort((a,b) -> {
            int ay = a.rect == null ? 0 : a.rect.top;
            int by = b.rect == null ? 0 : b.rect.top;
            if (Math.abs(ay - by) > 14) return Integer.compare(ay, by);
            int ax = a.rect == null ? 0 : a.rect.left;
            int bx = b.rect == null ? 0 : b.rect.left;
            return Integer.compare(ax, bx);
        });
        return out;
    }

    private Bitmap loadFirstPage(Uri uri, int targetMaxSide) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        String mime = resolver.getType(uri);
        if (mime != null && mime.toLowerCase(Locale.ROOT).contains("pdf")) return renderPdf(uri, targetMaxSide);
        Bitmap b = decodeImage(uri, targetMaxSide);
        if (b != null) return b;
        try { return renderPdf(uri, targetMaxSide); } catch (Exception ignored) { return null; }
    }

    private Bitmap decodeImage(Uri uri, int targetMaxSide) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in != null) BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        int max = Math.max(bounds.outWidth, bounds.outHeight);
        while (max / sample > targetMaxSide * 1.35f) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap src;
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            src = in == null ? null : BitmapFactory.decodeStream(in, null, opts);
        }
        if (src == null) return null;
        int srcMax = Math.max(src.getWidth(), src.getHeight());
        if (srcMax <= targetMaxSide) return src;
        float f = targetMaxSide / (float) srcMax;
        Bitmap scaled = Bitmap.createScaledBitmap(src, Math.max(1, Math.round(src.getWidth()*f)), Math.max(1, Math.round(src.getHeight()*f)), true);
        if (scaled != src) src.recycle();
        return scaled;
    }

    private Bitmap renderPdf(Uri uri, int targetMaxSide) throws Exception {
        ParcelFileDescriptor pfd = null;
        PdfRenderer renderer = null;
        PdfRenderer.Page page = null;
        try {
            pfd = context.getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) return null;
            renderer = new PdfRenderer(pfd);
            if (renderer.getPageCount() < 1) return null;
            page = renderer.openPage(0);
            int sw = Math.max(1, page.getWidth()), sh = Math.max(1, page.getHeight());
            float scale = targetMaxSide / (float)Math.max(sw, sh);
            if (scale < 1.35f) scale = 1.35f;
            if (scale > 3.0f) scale = 3.0f;
            int w = Math.max(1, Math.round(sw*scale)), h = Math.max(1, Math.round(sh*scale));
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            b.eraseColor(Color.WHITE);
            Matrix m = new Matrix();
            m.setScale(w/(float)sw, h/(float)sh);
            page.render(b, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            return b;
        } finally {
            if (page != null) try { page.close(); } catch (Exception ignored) {}
            if (renderer != null) try { renderer.close(); } catch (Exception ignored) {}
            if (pfd != null) try { pfd.close(); } catch (Exception ignored) {}
        }
    }

    private static final class LineInfo {
        final String text;
        final Rect rect;
        LineInfo(String text, Rect rect) { this.text = text; this.rect = rect; }
    }
}
