package br.com.jeanalan9.controlefiscalpcm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConsultaNfeActivity extends Activity {
    public static final String EXTRA_KEY = "fiscal_key";
    public static final String EXTRA_TYPE = "fiscal_type";
    public static final String EXTRA_RAW_URL = "fiscal_raw_url";
    public static final String EXTRA_RESULT_JSON = "fiscal_lookup_json";
    public static final String EXTRA_ERROR = "fiscal_lookup_error";

    private static final String URL_MG = "https://nfe.fazenda.mg.gov.br/portalnfe/sistema/consultaarg.xhtml";
    private static final String URL_NACIONAL = "https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ%2BgAVw2g%3D";
    private static final String URL_NFSE = "https://www.nfse.gov.br/ConsultaPublica/?tpc=1";

    private WebView webView;
    private TextView status;
    private ProgressBar progress;
    private String key = "";
    private String type = "NFE";
    private String rawUrl = "";
    private boolean completed = false;
    private boolean pageBusy = false;
    private boolean nationalFallback = false;
    private boolean autoSubmitAttempted = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable monitor = new Runnable() {
        @Override public void run() {
            if (!isFinishing() && !completed) {
                inspectPage();
                handler.postDelayed(this, 850);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) window.setDecorFitsSystemWindows(false);

        key = nz(getIntent().getStringExtra(EXTRA_KEY));
        type = nz(getIntent().getStringExtra(EXTRA_TYPE)).trim().toUpperCase(Locale.ROOT);
        rawUrl = nz(getIntent().getStringExtra(EXTRA_RAW_URL)).trim();
        if (type.isEmpty()) type = "NFE";
        if ("NFSE".equals(type)) key = key.replaceAll("[^0-9A-Za-z]", "");
        else key = key.replaceAll("\\D", "");

        if ("NFSE".equals(type)) {
            if (key.length() != 50) {
                String extracted = extractNfseKey(rawUrl);
                if (!extracted.isEmpty()) key = extracted;
            }
            if (key.length() != 50) { finishWithError("A chave de acesso da NFS-e não possui 50 caracteres."); return; }
        } else {
            if (key.length() != 44) { finishWithError("A chave de acesso da NF-e não possui 44 dígitos."); return; }
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.setClipToPadding(true);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setBackgroundColor(Color.WHITE);
        root.addView(column, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), 0, dp(12), 0);
        column.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));

        TextView back = new TextView(this);
        back.setText("‹  Voltar"); back.setTextSize(15); back.setTextColor(Color.rgb(11,140,104)); back.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(back, new LinearLayout.LayoutParams(dp(92), LinearLayout.LayoutParams.MATCH_PARENT));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { cancelLookup(); }
        });

        TextView titleView = new TextView(this);
        titleView.setText("NFSE".equals(type) ? "Consulta oficial da NFS-e" : "Consulta oficial da NF-e");
        titleView.setTextColor(Color.rgb(21,33,30)); titleView.setTextSize(18); titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD); titleView.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(titleView, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        status = new TextView(this);
        status.setText("Preparando consulta fiscal e preenchendo a chave automaticamente...");
        status.setTextColor(Color.rgb(88,104,98)); status.setTextSize(13); status.setPadding(dp(16),dp(9),dp(16),dp(9)); status.setBackgroundColor(Color.rgb(239,249,245));
        column.addView(status, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        column.addView(progress, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true); settings.setLoadWithOverviewMode(true); settings.setUseWideViewPort(true); settings.setSupportZoom(true); settings.setBuiltInZoomControls(true); settings.setDisplayZoomControls(false); settings.setDefaultTextEncodingName("UTF-8");
        settings.setUserAgentString(settings.getUserAgentString() + " ControleFiscalPCM/0.4.0");
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progress.setVisibility(View.VISIBLE);
                setStatus("Carregando consulta oficial...");
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                handler.postDelayed(new Runnable() {
                    @Override public void run() { ConsultaNfeActivity.this.inspectPage(); }
                }, 300);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    if (!"NFSE".equals(type) && !nationalFallback) {
                        nationalFallback = true;
                        setStatus("O portal estadual não respondeu. Abrindo o Portal Nacional da NF-e...");
                        view.loadUrl(URL_NACIONAL);
                    } else setStatus("Não foi possível abrir a consulta. Verifique a internet ou volte e preencha manualmente.");
                }
            }
        });
        column.addView(webView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
            int top=0,bottom=0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets safe=insets.getInsets(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars()|WindowInsets.Type.displayCutout()); top=safe.top; bottom=safe.bottom;
            } else { top=insets.getSystemWindowInsetTop(); bottom=insets.getSystemWindowInsetBottom(); }
            v.setPadding(0,top,0,bottom);
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ? WindowInsets.CONSUMED : insets.consumeSystemWindowInsets();
        
            }
        });
        setContentView(root); root.requestApplyInsets();

        String initial;
        if ("NFSE".equals(type)) {
            initial = isAllowedNfseUrl(rawUrl) ? rawUrl : URL_NFSE + "&chave=" + Uri.encode(key);
            nationalFallback = true;
        } else {
            String uf = key.substring(0,2);
            initial = "31".equals(uf) ? URL_MG : URL_NACIONAL;
            nationalFallback = !"31".equals(uf);
        }
        webView.loadUrl(initial);
        handler.postDelayed(monitor, 650);
    }

    private void inspectPage() {
        if (webView == null || completed || pageBusy) return;
        pageBusy = true;
        String script = "(() => {const body=document.body;if(!body)return '';let p=[body.innerText||''];for(const e of document.querySelectorAll('input,textarea,select')){const v=(e.value||'').trim();if(v)p.push((e.name||e.id||'campo')+': '+v)}return p.join('\\n')})()";
        webView.evaluateJavascript(script, new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
            pageBusy = false;
            String text = decodeJsString(value);
            if (text.trim().isEmpty()) return;
            if (looksLikeResult(text)) {
                FiscalData d = parseFiscalData(text);
                if (d.hasUsefulData()) { complete(d); return; }
            }
            autoFillAndSubmit(text);
            }
        });
    }

    private void autoFillAndSubmit(String pageText) {
        final int expected = "NFSE".equals(type) ? 50 : 44;
        final String js = "(() => {const key="+JSONObject.quote(key)+";const expected="+expected+";const inputs=Array.from(document.querySelectorAll('input')).filter(e=>!['hidden','submit','button','checkbox','radio'].includes((e.type||'').toLowerCase()));const score=e=>{const m=[e.name,e.id,e.placeholder,e.getAttribute('aria-label'),e.title].filter(Boolean).join(' ').toLowerCase();let s=0;if(m.includes('chave'))s+=15;if(m.includes('acesso'))s+=8;if(m.includes('nfse')||m.includes('nfs-e')||m.includes('nfe'))s+=4;if((e.maxLength||0)===expected)s+=12;return s};let ranked=inputs.map(e=>({e,s:score(e)})).sort((a,b)=>b.s-a.s);let target=ranked.length&&ranked[0].s>0?ranked[0].e:inputs.find(e=>(e.maxLength||0)>=expected);if(target){const clean=v=>expected===44?String(v||'').replace(/\\D/g,''):String(v||'').replace(/[^0-9A-Za-z]/g,'');if(clean(target.value)!==key){const d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');if(d&&d.set)d.set.call(target,key);else target.value=key;target.dispatchEvent(new Event('input',{bubbles:true}));target.dispatchEvent(new Event('change',{bubbles:true}));target.dispatchEvent(new Event('blur',{bubbles:true}));}const txt=(document.body.innerText||'').toLowerCase();const human=/captcha|não sou um robô|nao sou um robo|código impresso|codigo impresso|recaptcha/.test(txt);if(!human&&!window.__pcmSubmitted){const btn=Array.from(document.querySelectorAll('button,input[type=submit],a')).find(b=>/consultar|pesquisar|buscar/.test((b.innerText||b.value||'').trim().toLowerCase()));if(btn){window.__pcmSubmitted=true;setTimeout(()=>btn.click(),180);return 'submitted'}}return human?'human':'filled'}return 'waiting'})()";
        webView.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
            String state = decodeJsString(value).toLowerCase(Locale.ROOT);
            if (state.contains("human")) setStatus("Chave preenchida. Conclua a validação de segurança/“Não sou robô” e toque em Consultar. O app retornará os dados automaticamente.");
            else if (state.contains("submitted")) { autoSubmitAttempted = true; setStatus("Chave preenchida. Consultando automaticamente..."); }
            else if (state.contains("filled")) setStatus("Chave preenchida. Aguardando o portal concluir a consulta...");
            else setStatus("Aguardando a página de consulta. Se solicitado, conclua a validação de segurança.");
            }
        });
    }

    private boolean looksLikeResult(String text) {
        String f=fold(text);
        boolean issuer = "NFSE".equals(type) ? containsAny(f,new String[]{"prestador de servicos","prestador","emitente","razao social"}) : containsAny(f,new String[]{"emitente","razao social","nome / razao social"});
        boolean date = containsAny(f,new String[]{"data de emissao","data emissao","data/hora de emissao","data/hora da emissao","emissao"});
        boolean total = "NFSE".equals(type) ? containsAny(f,new String[]{"valor do servico","valor total da nfs-e","valor total da nfse","valor liquido","valor da nota","valor total"}) : containsAny(f,new String[]{"valor total da nota","valor total da nf-e","valor total nfe","valor da nota","valor total"});
        String compact=text.replaceAll("[^0-9A-Za-z]","");
        boolean hasKey=compact.contains(key);
        return (issuer&&date&&total)||(hasKey&&date&&total);
    }

    private FiscalData parseFiscalData(String text) {
        FiscalData d=new FiscalData();
        if ("NFSE".equals(type)) {
            String tif=key.substring(8,9), federal=key.substring(9,23);
            if ("2".equals(tif)) d.cnpj=formatCnpj(federal); else if ("1".equals(tif)) d.cnpj=formatCpf(federal.substring(Math.max(0,federal.length()-11)));
            d.numero=stripLeadingZeros(key.substring(23,36)); d.serie=""; d.tipoDocumento="NFS-e";
        } else {
            d.cnpj=formatCnpj(key.substring(6,20)); d.numero=stripLeadingZeros(key.substring(25,34)); d.serie=stripLeadingZeros(key.substring(22,25)); d.tipoDocumento="55".equals(key.substring(20,22))?"NF-e":"NFC-e";
        }
        List<String> lines=splitLines(text);
        d.emissao=findDateAfterLabels(lines,new String[]{"data/hora de emissão","data/hora da emissão","data da emissão","data de emissão","data emissão","emissão"});
        d.valor=findMoneyAfterLabels(lines, "NFSE".equals(type)?new String[]{"valor total da nfs-e","valor total da nfse","valor do serviço","valor do servico","valor líquido","valor liquido","valor da nota","valor total"}:new String[]{"valor total da nota fiscal","valor total da nf-e","valor total nfe","valor total da nota","valor da nota","valor total"});
        d.fornecedor=findIssuerName(lines);
        d.diagnostico="NFSE".equals(type)?"ORDEM_SERVICO":suggestDiagnosis(text);
        return d;
    }

    private String findIssuerName(List<String> lines) {
        int start=0,end=Math.min(lines.size(),140);
        for(int i=0;i<lines.size();i++){
            String f=fold(lines.get(i));
            if (f.equals("emitente")||f.contains("dados do emitente")||f.contains("prestador de servicos")||f.equals("prestador")) { start=i; end=Math.min(lines.size(),i+60); break; }
        }
        for(int i=start;i<end;i++){
            String f=fold(lines.get(i));
            if ((f.contains("destinatario")||f.contains("tomador"))&&i>start+2) break;
            if (f.contains("nome / razao social")||f.contains("nome/razao social")||f.equals("razao social")||f.contains("razao social do emitente")||f.contains("nome empresarial")||f.contains("prestador")) {
                String same=valueAfterColon(lines.get(i)); if(looksLikeCompanyName(same))return same;
                for(int j=i+1;j<Math.min(end,i+6);j++){String c=lines.get(j).trim();if(looksLikeCompanyName(c))return c;}
            }
        }
        String idDigits="";
        if ("NFSE".equals(type)) idDigits=key.substring(9,23).replaceFirst("^0+(?!$)",""); else idDigits=key.substring(6,20);
        for(int i=0;i<lines.size();i++) if(lines.get(i).replaceAll("\\D","").contains(idDigits)) for(int j=Math.max(0,i-7);j<=Math.min(lines.size()-1,i+4);j++){String c=lines.get(j).trim();if(looksLikeCompanyName(c))return c;}
        return "";
    }

    private String findDateAfterLabels(List<String> lines,String[] labels){Pattern p=Pattern.compile("(\\d{2}/\\d{2}/\\d{4})");for(int i=0;i<lines.size();i++){String f=fold(lines.get(i));if(!containsAny(f,labels))continue;for(int j=i;j<Math.min(lines.size(),i+6);j++){Matcher m=p.matcher(lines.get(j));if(m.find())return m.group(1);}}return "";}
    private String findMoneyAfterLabels(List<String> lines,String[] labels){Pattern p=Pattern.compile("(?:R\\$\\s*)?([0-9]{1,3}(?:\\.[0-9]{3})*,[0-9]{2}|[0-9]+,[0-9]{2})");for(int i=0;i<lines.size();i++){String f=fold(lines.get(i));if(!containsAny(f,labels))continue;for(int j=i;j<Math.min(lines.size(),i+6);j++){Matcher m=p.matcher(lines.get(j));while(m.find()){String v=m.group(1);if(!"0,00".equals(v))return "R$ "+v;}}}return "";}
    private String suggestDiagnosis(String text){String f=fold(text);if(containsAny(f,new String[]{"gasolina","diesel","etanol","combustivel","lubrificante","oleo lubrificante","arla 32","auto posto"}))return "ABASTECIMENTO_OLEO";if(containsAny(f,new String[]{"manutencao preventiva","preventiva","revisao preventiva"}))return "ALERTA_PREVENTIVA";if(containsAny(f,new String[]{"servico","mao de obra","conserto","reparo","manutencao","oficina"}))return "ORDEM_SERVICO";if(containsAny(f,new String[]{"peca","material","produto","almoxarifado"}))return "ESTOQUE";return "";}

    private void complete(FiscalData d){if(completed)return;completed=true;try{JSONObject o=new JSONObject();o.put("ok",true);o.put("numero",d.numero);o.put("serie",d.serie);o.put("fornecedor",d.fornecedor);o.put("cnpj",d.cnpj);o.put("emissao",d.emissao);o.put("valor",d.valor);o.put("diagnostico",d.diagnostico);o.put("tipoDocumento",d.tipoDocumento);o.put("modelo","NFSE".equals(type)?"NFS-e":key.substring(20,22));o.put("fonte","NFSE".equals(type)?"Portal Nacional NFS-e":(nationalFallback?"Portal Nacional NF-e":"SEFAZ MG"));Intent r=new Intent();r.putExtra(EXTRA_RESULT_JSON,o.toString());setResult(RESULT_OK,r);finish();}catch(Exception e){completed=false;setStatus("Dados localizados, mas não foi possível retorná-los ao aplicativo. Volte e preencha manualmente.");}}
    private void cancelLookup(){Intent r=new Intent();r.putExtra(EXTRA_ERROR,"Consulta cancelada. Os dados identificados pelo código foram preservados.");setResult(RESULT_CANCELED,r);finish();}
    private void finishWithError(String m){Intent r=new Intent();r.putExtra(EXTRA_ERROR,m);setResult(RESULT_CANCELED,r);finish();}
    private void setStatus(String t){if(status!=null)status.setText(t);}

    private static String extractNfseKey(String raw){if(raw==null)return "";String d=raw;try{d=URLDecoder.decode(raw,"UTF-8");}catch(Exception ignored){}Matcher m=Pattern.compile("(?:[?&]|\\b)chave=([^&#\\s]+)",Pattern.CASE_INSENSITIVE).matcher(d);if(m.find()){String c=m.group(1).replaceAll("[^0-9A-Za-z]","");if(c.length()>=50)return c.substring(0,50);}String compact=d.replaceAll("[^0-9A-Za-z]","");return compact.length()==50?compact:"";}
    private static boolean isAllowedNfseUrl(String u){if(u==null||u.isEmpty())return false;try{Uri x=Uri.parse(u);String h=x.getHost();return "https".equalsIgnoreCase(x.getScheme())&&h!=null&&(h.equalsIgnoreCase("www.nfse.gov.br")||h.endsWith(".nfse.gov.br"));}catch(Exception e){return false;}}
    private static List<String> splitLines(String text){List<String> out=new ArrayList<>();if(text==null)return out;String normalized=text.replace('\u00A0',' ').replace("\\r","\\n");for(String raw:normalized.split("\\n+")){String s=raw.replaceAll("\\s+"," ").trim();if(!s.isEmpty())out.add(s);}return out;}
    private static boolean looksLikeCompanyName(String s){if(s==null)return false;String t=s.trim();if(t.length()<4||t.length()>160)return false;String f=foldStatic(t);if(containsAny(f,new String[]{"razao social","emitente","prestador de servicos","cnpj","cpf","inscricao","endereco","municipio","cep","tomador"}))return false;if(t.matches(".*\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}-\\d{2}.*"))return false;int letters=0;for(int i=0;i<t.length();i++)if(Character.isLetter(t.charAt(i)))letters++;return letters>=4;}
    private static String valueAfterColon(String s){if(s==null)return "";int i=s.indexOf(':');return i>=0&&i+1<s.length()?s.substring(i+1).trim():"";}
    private static boolean containsAny(String f,String[] terms){if(f==null)return false;for(String t:terms)if(f.contains(foldStatic(t)))return true;return false;}
    private static String formatCnpj(String digits){String d=digits==null?"":digits.replaceAll("\\D","");if(d.length()!=14)return digits==null?"":digits;return d.substring(0,2)+"."+d.substring(2,5)+"."+d.substring(5,8)+"/"+d.substring(8,12)+"-"+d.substring(12,14);}
    private static String formatCpf(String digits){String d=digits==null?"":digits.replaceAll("\\D","");if(d.length()!=11)return digits==null?"":digits;return d.substring(0,3)+"."+d.substring(3,6)+"."+d.substring(6,9)+"-"+d.substring(9,11);}
    private static String stripLeadingZeros(String v){String x=v==null?"":v.replaceFirst("^0+(?!$)","");return x.isEmpty()?"0":x;}
    private String decodeJsString(String value){if(value==null||"null".equals(value))return "";try{return new org.json.JSONArray("["+value+"]").getString(0);}catch(Exception ignored){return value.replaceAll("^\"|\"$","");}}
    private String fold(String v){return foldStatic(v);}private static String foldStatic(String v){return Normalizer.normalize(v==null?"":v,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);}
    private static String nz(String s){return s==null?"":s;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else cancelLookup();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(webView!=null){webView.stopLoading();webView.destroy();}super.onDestroy();}

    private static final class FiscalData {String numero="",serie="",fornecedor="",cnpj="",emissao="",valor="",diagnostico="",tipoDocumento="";boolean hasUsefulData(){return !fornecedor.isEmpty()||!emissao.isEmpty()||!valor.isEmpty();}}
}
