package br.com.jeanalan9.controlefiscalpcm;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.Camera;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

@SuppressWarnings("deprecation")
public class ScannerActivity extends Activity implements SurfaceHolder.Callback, Camera.PreviewCallback {
    public static final String EXTRA_RESULT = "scan_result";
    public static final String EXTRA_FORMAT = "scan_format";
    private static final int REQ_CAMERA = 6102;
    private static final long DECODE_INTERVAL_MS = 110L;

    private FrameLayout root;
    private SurfaceView preview;
    private SurfaceHolder holder;
    private Camera camera;
    private TextView status;
    private TextView torchButton;
    private boolean surfaceReady = false;
    private boolean torchOn = false;
    private int previewWidth = 0;
    private int previewHeight = 0;
    private int displayOrientation = 90;
    private long lastDecodeAt = 0L;
    private final AtomicBoolean decoding = new AtomicBoolean(false);
    private final AtomicBoolean finished = new AtomicBoolean(false);
    private final ExecutorService decoderExecutor = Executors.newSingleThreadExecutor();
    private final ZxingDecoder decoder = new ZxingDecoder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setClipToPadding(true);

        preview = new SurfaceView(this);
        holder = preview.getHolder();
        holder.addCallback(this);
        root.addView(preview, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        ScannerOverlay overlay = new ScannerOverlay(this);
        root.addView(overlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        TextView close = makeButton("‹  Voltar");
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(dp(104), dp(44));
        closeLp.gravity = Gravity.TOP | Gravity.START;
        closeLp.leftMargin = dp(16);
        closeLp.topMargin = dp(14);
        root.addView(close, closeLp);
        close.setOnClickListener(v -> cancelScan());

        torchButton = makeButton("Lanterna");
        FrameLayout.LayoutParams torchLp = new FrameLayout.LayoutParams(dp(104), dp(44));
        torchLp.gravity = Gravity.TOP | Gravity.END;
        torchLp.rightMargin = dp(16);
        torchLp.topMargin = dp(14);
        root.addView(torchButton, torchLp);
        torchButton.setOnClickListener(v -> toggleTorch());

        status = new TextView(this);
        status.setText("Aponte para a chave de acesso, QR Code ou código de barras da nota fiscal");
        status.setTextColor(Color.WHITE);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(24), dp(10), dp(24), dp(10));
        status.setBackgroundColor(Color.argb(125, 0, 0, 0));
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(76));
        statusLp.gravity = Gravity.BOTTOM;
        statusLp.leftMargin = dp(18);
        statusLp.rightMargin = dp(18);
        statusLp.bottomMargin = dp(24);
        root.addView(status, statusLp);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int topInset;
            int bottomInset;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets safe = insets.getInsets(WindowInsets.Type.statusBars()
                        | WindowInsets.Type.navigationBars()
                        | WindowInsets.Type.displayCutout());
                topInset = safe.top;
                bottomInset = safe.bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, topInset, 0, bottomInset);
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                    ? WindowInsets.CONSUMED
                    : insets.consumeSystemWindowInsets();
        });

        setContentView(root);
        root.requestApplyInsets();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private TextView makeButton(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(Color.argb(155, 12, 38, 50));
        return v;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                maybeStartCamera();
            } else {
                status.setText("Permissão da câmera é necessária para escanear.");
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        maybeStartCamera();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (camera != null) {
            try { camera.stopPreview(); } catch (Exception ignored) {}
            configureCamera(camera);
            try {
                camera.setPreviewDisplay(holder);
                camera.setPreviewCallback(this);
                camera.startPreview();
            } catch (Exception e) {
                status.setText("Não foi possível reiniciar a câmera.");
            }
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        releaseCamera();
    }

    private void maybeStartCamera() {
        if (!surfaceReady || camera != null || finished.get()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            camera = Camera.open();
            configureCamera(camera);
            camera.setPreviewDisplay(holder);
            camera.setPreviewCallback(this);
            camera.startPreview();
            status.setText("Centralize o código dentro da moldura. A leitura é automática.");
        } catch (Exception e) {
            status.setText("Não foi possível acessar a câmera: " + e.getMessage());
            releaseCamera();
        }
    }

    private void configureCamera(Camera cam) {
        try {
            Camera.Parameters p = cam.getParameters();
            Camera.Size selected = choosePreviewSize(p.getSupportedPreviewSizes());
            if (selected != null) {
                p.setPreviewSize(selected.width, selected.height);
                previewWidth = selected.width;
                previewHeight = selected.height;
            } else if (p.getPreviewSize() != null) {
                previewWidth = p.getPreviewSize().width;
                previewHeight = p.getPreviewSize().height;
            }

            List<String> sceneModes = p.getSupportedSceneModes();
            if (sceneModes != null && sceneModes.contains(Camera.Parameters.SCENE_MODE_BARCODE)) {
                p.setSceneMode(Camera.Parameters.SCENE_MODE_BARCODE);
            }

            List<String> focusModes = p.getSupportedFocusModes();
            if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            } else if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            } else if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            }

            List<int[]> ranges = p.getSupportedPreviewFpsRange();
            if (ranges != null && !ranges.isEmpty()) {
                int[] best = ranges.get(0);
                for (int[] r : ranges) {
                    if (r != null && r.length >= 2 && r[1] > best[1]) best = r;
                }
                if (best != null && best.length >= 2) p.setPreviewFpsRange(best[0], best[1]);
            }

            cam.setParameters(p);
            displayOrientation = calculateDisplayOrientation();
            cam.setDisplayOrientation(displayOrientation);
        } catch (Exception ignored) {
        }
    }

    private Camera.Size choosePreviewSize(List<Camera.Size> sizes) {
        if (sizes == null || sizes.isEmpty()) return null;
        Camera.Size best = null;
        long bestScore = Long.MAX_VALUE;
        long target = 1280L * 720L;
        for (Camera.Size s : sizes) {
            long area = (long) s.width * s.height;
            if (area < 640L * 480L) continue;
            long score = Math.abs(area - target);
            if (area > 1920L * 1080L) score += area;
            if (score < bestScore) {
                best = s;
                bestScore = score;
            }
        }
        return best != null ? best : sizes.get(0);
    }

    private int calculateDisplayOrientation() {
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(0, info);
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees;
        switch (rotation) {
            case Surface.ROTATION_90: degrees = 90; break;
            case Surface.ROTATION_180: degrees = 180; break;
            case Surface.ROTATION_270: degrees = 270; break;
            default: degrees = 0;
        }
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            int result = (info.orientation + degrees) % 360;
            return (360 - result) % 360;
        }
        return (info.orientation - degrees + 360) % 360;
    }

    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        if (finished.get() || data == null || previewWidth <= 0 || previewHeight <= 0) return;
        long now = System.currentTimeMillis();
        if (now - lastDecodeAt < DECODE_INTERVAL_MS || !decoding.compareAndSet(false, true)) return;
        lastDecodeAt = now;

        int ySize = previewWidth * previewHeight;
        if (data.length < ySize) {
            decoding.set(false);
            return;
        }
        byte[] luminance = new byte[ySize];
        System.arraycopy(data, 0, luminance, 0, ySize);
        final int width = previewWidth;
        final int height = previewHeight;
        final int orientation = displayOrientation;

        decoderExecutor.execute(() -> {
            try {
                ScanResult r = decoder.decode(luminance, width, height, orientation);
                if (r != null && r.text != null) {
                    String normalized = normalizeFiscalPayload(r.text, r.format);
                    if (!normalized.isEmpty() && finished.compareAndSet(false, true)) {
                        final ScanResult accepted = new ScanResult(normalized,
                                extractValidNfeKey(normalized).isEmpty() ? r.format : "NF_E_CHAVE_44");
                        runOnUiThread(() -> finishWithResult(accepted));
                    }
                }
            } finally {
                decoding.set(false);
            }
        });
    }

    private static String normalizeFiscalPayload(String text, String format) {
        if (text == null) return "";
        String t = text.trim();
        if (t.isEmpty()) return "";
        String key = extractValidNfeKey(t);
        if (!key.isEmpty()) return key;
        String low = t.toLowerCase();
        if ((low.startsWith("http://") || low.startsWith("https://")) &&
                (low.contains("nf") || low.contains("fazenda") || low.contains("gov.br") || low.contains("nota"))) {
            return t;
        }
        String f = format == null ? "" : format.toUpperCase();
        if ((f.contains("QR") || f.contains("DATA_MATRIX") || f.contains("PDF_417") || f.contains("AZTEC")) && t.length() >= 12) {
            return t;
        }
        return "";
    }

    private static String extractValidNfeKey(String raw) {
        String digits = raw == null ? "" : raw.replaceAll("\\D", "");
        if (digits.length() < 44) return "";
        if (digits.length() == 44 && isValidNfeKey(digits)) return digits;
        for (int i = 0; i + 44 <= digits.length(); i++) {
            String c = digits.substring(i, i + 44);
            if (isValidNfeKey(c) && ("55".equals(c.substring(20, 22)) || "65".equals(c.substring(20, 22)))) {
                return c;
            }
        }
        return "";
    }

    private static boolean isValidNfeKey(String key) {
        if (key == null || key.length() != 44 || !key.matches("\\d{44}")) return false;
        int sum = 0;
        int weight = 2;
        for (int i = 42; i >= 0; i--) {
            sum += Character.digit(key.charAt(i), 10) * weight;
            weight++;
            if (weight > 9) weight = 2;
        }
        int remainder = sum % 11;
        int dv = 11 - remainder;
        if (dv == 10 || dv == 11) dv = 0;
        return dv == Character.digit(key.charAt(43), 10);
    }

    private void finishWithResult(ScanResult result) {
        try {
            new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
                    .startTone(ToneGenerator.TONE_PROP_BEEP, 120);
        } catch (Exception ignored) {}
        Intent data = new Intent();
        data.putExtra(EXTRA_RESULT, result.text.trim());
        data.putExtra(EXTRA_FORMAT, result.format == null ? "" : result.format);
        setResult(RESULT_OK, data);
        releaseCamera();
        finish();
    }

    private void toggleTorch() {
        if (camera == null) return;
        try {
            Camera.Parameters p = camera.getParameters();
            List<String> modes = p.getSupportedFlashModes();
            if (modes == null || !modes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                status.setText("Lanterna não disponível neste aparelho.");
                return;
            }
            torchOn = !torchOn;
            p.setFlashMode(torchOn ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(p);
            torchButton.setText(torchOn ? "Lanterna ON" : "Lanterna");
        } catch (Exception ignored) {
        }
    }

    private void cancelScan() {
        if (finished.compareAndSet(false, true)) {
            setResult(RESULT_CANCELED);
            releaseCamera();
            finish();
        }
    }

    private void releaseCamera() {
        Camera c = camera;
        camera = null;
        if (c != null) {
            try { c.setPreviewCallback(null); } catch (Exception ignored) {}
            try { c.stopPreview(); } catch (Exception ignored) {}
            try { c.release(); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onPause() {
        releaseCamera();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        maybeStartCamera();
    }

    @Override
    protected void onDestroy() {
        releaseCamera();
        decoderExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        cancelScan();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class ScanResult {
        final String text;
        final String format;
        ScanResult(String text, String format) {
            this.text = text;
            this.format = format;
        }
    }

    private static final class ZxingDecoder {
        private Object reader;
        private Constructor<?> sourceCtor;
        private Constructor<?> hybridCtor;
        private Constructor<?> bitmapCtor;
        private Method decodeMethod;
        private Method resetMethod;
        private Method getTextMethod;
        private Method getFormatMethod;
        private boolean available;

        @SuppressWarnings({"unchecked", "rawtypes"})
        ZxingDecoder() {
            try {
                Class<?> luminance = Class.forName("com.google.zxing.LuminanceSource");
                Class<?> binarizer = Class.forName("com.google.zxing.Binarizer");
                Class<?> bitmap = Class.forName("com.google.zxing.BinaryBitmap");
                Class<?> planar = Class.forName("com.google.zxing.PlanarYUVLuminanceSource");
                Class<?> hybrid = Class.forName("com.google.zxing.common.HybridBinarizer");
                Class<?> readerClass = Class.forName("com.google.zxing.MultiFormatReader");
                Class<?> resultClass = Class.forName("com.google.zxing.Result");
                Class<?> hintClass = Class.forName("com.google.zxing.DecodeHintType");
                Class<?> formatClass = Class.forName("com.google.zxing.BarcodeFormat");

                sourceCtor = planar.getConstructor(byte[].class, int.class, int.class,
                        int.class, int.class, int.class, int.class, boolean.class);
                hybridCtor = hybrid.getConstructor(luminance);
                bitmapCtor = bitmap.getConstructor(binarizer);
                reader = readerClass.getConstructor().newInstance();

                Map<Object, Object> hints = new HashMap<>();
                Object tryHarder = Enum.valueOf((Class<? extends Enum>) hintClass, "TRY_HARDER");
                Object possible = Enum.valueOf((Class<? extends Enum>) hintClass, "POSSIBLE_FORMATS");
                Object charset = Enum.valueOf((Class<? extends Enum>) hintClass, "CHARACTER_SET");
                hints.put(tryHarder, Boolean.TRUE);
                hints.put(charset, "UTF-8");
                List<Object> formats = new ArrayList<>();
                String[] wanted = {"CODE_128", "QR_CODE", "DATA_MATRIX", "PDF_417", "AZTEC", "CODE_39", "ITF", "EAN_13"};
                for (String name : wanted) {
                    try { formats.add(Enum.valueOf((Class<? extends Enum>) formatClass, name)); } catch (Exception ignored) {}
                }
                hints.put(possible, formats);
                try {
                    Method setHints = readerClass.getMethod("setHints", Map.class);
                    setHints.invoke(reader, hints);
                } catch (Exception ignored) {}

                try { decodeMethod = readerClass.getMethod("decodeWithState", bitmap); }
                catch (Exception e) { decodeMethod = readerClass.getMethod("decode", bitmap); }
                resetMethod = readerClass.getMethod("reset");
                getTextMethod = resultClass.getMethod("getText");
                getFormatMethod = resultClass.getMethod("getBarcodeFormat");
                available = true;
            } catch (Exception e) {
                available = false;
            }
        }

        ScanResult decode(byte[] y, int width, int height, int orientation) {
            if (!available) return null;
            if (orientation == 90 || orientation == 270) {
                byte[] rotated = orientation == 90 ? rotate90(y, width, height) : rotate270(y, width, height);
                int rw = height;
                int rh = width;
                ScanResult region = decodeCenterRegion(rotated, rw, rh);
                if (region != null) return region;
                ScanResult full = decodeOnce(rotated, rw, rh, 0, 0, rw, rh);
                if (full != null) return full;
                return decodeCenterRegion(y, width, height);
            }
            ScanResult region = decodeCenterRegion(y, width, height);
            if (region != null) return region;
            return decodeOnce(y, width, height, 0, 0, width, height);
        }

        private ScanResult decodeCenterRegion(byte[] y, int width, int height) {
            int left = Math.max(0, Math.round(width * 0.04f));
            int top = Math.max(0, Math.round(height * 0.18f));
            int cw = Math.min(width - left, Math.round(width * 0.92f));
            int ch = Math.min(height - top, Math.round(height * 0.58f));
            return decodeOnce(y, width, height, left, top, cw, ch);
        }

        private ScanResult decodeOnce(byte[] y, int width, int height, int left, int top, int cropW, int cropH) {
            try {
                if (cropW <= 0 || cropH <= 0 || left < 0 || top < 0 || left + cropW > width || top + cropH > height) return null;
                Object source = sourceCtor.newInstance(y, width, height, left, top, cropW, cropH, false);
                Object hybrid = hybridCtor.newInstance(source);
                Object bitmap = bitmapCtor.newInstance(hybrid);
                Object result = decodeMethod.invoke(reader, bitmap);
                String text = String.valueOf(getTextMethod.invoke(result));
                Object format = getFormatMethod.invoke(result);
                try { resetMethod.invoke(reader); } catch (Exception ignored) {}
                return new ScanResult(text, String.valueOf(format));
            } catch (Exception ignored) {
                try { resetMethod.invoke(reader); } catch (Exception ignored2) {}
                return null;
            }
        }

        private static byte[] rotate90(byte[] data, int width, int height) {
            byte[] rotated = new byte[width * height];
            int index = 0;
            for (int x = 0; x < width; x++) {
                for (int y = height - 1; y >= 0; y--) {
                    rotated[index++] = data[y * width + x];
                }
            }
            return rotated;
        }

        private static byte[] rotate270(byte[] data, int width, int height) {
            byte[] rotated = new byte[width * height];
            int index = 0;
            for (int x = width - 1; x >= 0; x--) {
                for (int yy = 0; yy < height; yy++) {
                    rotated[index++] = data[yy * width + x];
                }
            }
            return rotated;
        }
    }

    private static final class ScannerOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);

        ScannerOverlay(android.content.Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            line.setStrokeWidth(dpStatic(context, 2));
            line.setColor(Color.rgb(41, 215, 158));
            line.setShadowLayer(dpStatic(context, 9), 0, 0, Color.rgb(41, 215, 158));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float boxW = w * 0.82f;
            float boxH = Math.min(h * 0.36f, boxW * 0.70f);
            float left = (w - boxW) / 2f;
            float top = (h - boxH) / 2f - h * 0.02f;
            RectF box = new RectF(left, top, left + boxW, top + boxH);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(95, 0, 0, 0));
            canvas.drawRect(0, 0, w, box.top, paint);
            canvas.drawRect(0, box.bottom, w, h, paint);
            canvas.drawRect(0, box.top, box.left, box.bottom, paint);
            canvas.drawRect(box.right, box.top, w, box.bottom, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpStatic(getContext(), 2));
            paint.setColor(Color.argb(220, 230, 240, 237));
            canvas.drawRoundRect(box, dpStatic(getContext(), 24), dpStatic(getContext(), 24), paint);
            canvas.drawLine(box.left + dpStatic(getContext(), 22), box.centerY(),
                    box.right - dpStatic(getContext(), 22), box.centerY(), line);
        }

        private static int dpStatic(android.content.Context c, int value) {
            return Math.round(value * c.getResources().getDisplayMetrics().density);
        }
    }
}
