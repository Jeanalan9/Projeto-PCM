package br.com.jeanalan9.controlefiscalpcm;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Lê QR Codes e códigos de barras a partir de imagens/PDFs selecionados pelo usuário.
 *
 * V0.4.8:
 * - busca por regiões prioritárias (topo, cantos, quadrantes e grade);
 * - ampliação seletiva de códigos pequenos;
 * - versões em tons de cinza, alto contraste e binarização;
 * - borda branca para melhorar quiet-zone de QR/1D;
 * - dois binarizadores ZXing quando disponíveis;
 * - suporte a recorte manual por Bitmap para o fallback visual.
 */
public final class ImportedDocumentDecoder {
    public static final class Result {
        public final String text;
        public final String format;

        Result(String text, String format) {
            this.text = text == null ? "" : text;
            this.format = format == null ? "" : format;
        }
    }

    private final Context context;
    private final BitmapZxingDecoder decoder = new BitmapZxingDecoder();

    public ImportedDocumentDecoder(Context context) {
        this.context = context.getApplicationContext();
    }

    public Result decode(Uri uri) throws Exception {
        if (uri == null) throw new IllegalArgumentException("Arquivo não informado.");
        ContentResolver resolver = context.getContentResolver();
        String mime = resolver.getType(uri);
        if (mime != null && mime.toLowerCase().contains("pdf")) {
            Result r = decodePdf(uri);
            if (r != null) return r;
            throw new IllegalArgumentException("Nenhum QR Code ou código de barras fiscal foi encontrado no PDF.");
        }

        Result r = decodeImage(uri);
        if (r != null) return r;

        // Alguns gerenciadores de arquivos não informam corretamente o MIME do PDF.
        try {
            r = decodePdf(uri);
            if (r != null) return r;
        } catch (Exception ignored) {}

        throw new IllegalArgumentException("Nenhum QR Code ou código de barras fiscal foi encontrado no arquivo.");
    }

    /** Permite que o fallback de recorte manual use exatamente o mesmo motor. */
    public Result decodeBitmap(Bitmap bitmap) {
        return decodeBitmapVariants(bitmap, true);
    }

    private Result decodeImage(Uri uri) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        InputStream probe = null;
        try {
            probe = resolver.openInputStream(uri);
            if (probe != null) BitmapFactory.decodeStream(probe, null, bounds);
        } finally {
            if (probe != null) try { probe.close(); } catch (Exception ignored) {}
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int maxSide = Math.max(bounds.outWidth, bounds.outHeight);
        int sample = 1;
        // Mantém mais detalhe que a V0.4.7 porque códigos fiscais podem ocupar uma área pequena da foto.
        while (maxSide / sample > 2600) sample *= 2;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        InputStream input = null;
        Bitmap bitmap = null;
        try {
            input = resolver.openInputStream(uri);
            if (input == null) return null;
            bitmap = BitmapFactory.decodeStream(input, null, opts);
            if (bitmap == null) return null;
            return decodeBitmapVariants(bitmap, false);
        } finally {
            if (input != null) try { input.close(); } catch (Exception ignored) {}
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private Result decodePdf(Uri uri) throws Exception {
        ParcelFileDescriptor descriptor = null;
        PdfRenderer renderer = null;
        try {
            descriptor = context.getContentResolver().openFileDescriptor(uri, "r");
            if (descriptor == null) return null;
            renderer = new PdfRenderer(descriptor);
            int pages = Math.min(renderer.getPageCount(), 8);
            for (int i = 0; i < pages; i++) {
                PdfRenderer.Page page = null;
                Bitmap bitmap = null;
                try {
                    page = renderer.openPage(i);
                    int sourceW = Math.max(1, page.getWidth());
                    int sourceH = Math.max(1, page.getHeight());
                    float scale = Math.min(2.6f, 2400.0f / Math.max(sourceW, sourceH));
                    if (scale < 1.25f) scale = 1.25f;
                    int width = Math.max(1, Math.round(sourceW * scale));
                    int height = Math.max(1, Math.round(sourceH * scale));
                    bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    bitmap.eraseColor(Color.WHITE);
                    Matrix matrix = new Matrix();
                    matrix.setScale((float) width / sourceW, (float) height / sourceH);
                    page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    Result result = decodeBitmapVariants(bitmap, false);
                    if (result != null) return result;
                } finally {
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                    if (page != null) try { page.close(); } catch (Exception ignored) {}
                }
            }
            return null;
        } finally {
            if (renderer != null) try { renderer.close(); } catch (Exception ignored) {}
            if (descriptor != null) try { descriptor.close(); } catch (Exception ignored) {}
        }
    }

    private Result decodeBitmapVariants(Bitmap original, boolean manualCrop) {
        if (original == null || original.isRecycled()) return null;

        // 1) Caminho rápido: procura primeiro exatamente onde QR/código de barras
        // costumam aparecer nas DANFEs/NFS-e. Evita dezenas de preprocessamentos
        // antes de testar os recortes mais prováveis.
        Result result = manualCrop ? null : decodeFastRegions(original);
        if (isValid(result)) return normalize(result);

        // 2) Imagem inteira: tentativa barata para códigos grandes.
        result = decodeCandidate(original, manualCrop ? 3 : 1);
        if (isValid(result)) return normalize(result);

        // 3) Busca priorizada sem girar. O caminho automático limita regiões;
        // o recorte manual mantém o tratamento agressivo.
        result = decodeRegions(original, manualCrop);
        if (isValid(result)) return normalize(result);

        // 4) Rotação completa apenas como fallback para arquivo em orientação incorreta.
        Bitmap rotated = null;
        Bitmap current = original;
        try {
            int[] angles = new int[]{90, 180, 270};
            for (int angle : angles) {
                Matrix m = new Matrix();
                m.postRotate(angle);
                try {
                    rotated = Bitmap.createBitmap(original, 0, 0, original.getWidth(), original.getHeight(), m, true);
                } catch (Exception e) {
                    rotated = null;
                }
                if (rotated == null) continue;
                current = rotated;

                result = decodeCandidate(current, 1);
                if (isValid(result)) return normalize(result);

                // Em rotações, usa regiões porém com preprocessamento moderado para não tornar a importação lenta demais.
                result = decodeRegions(current, false);
                if (isValid(result)) return normalize(result);

                current.recycle();
                rotated = null;
            }
            return null;
        } finally {
            if (rotated != null && !rotated.isRecycled()) rotated.recycle();
        }
    }


    private Result decodeFastRegions(Bitmap bitmap) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        if (w < 80 || h < 80) return null;

        // Ordem deliberada: QR pequeno da NFS-e nacional primeiro; em seguida
        // as faixas horizontais onde o DANFE normalmente imprime o CODE-128.
        float[][] boxes = new float[][]{
                {0.70f, 0.015f, 0.29f, 0.24f},
                {0.735f, 0.025f, 0.245f, 0.19f},
                {0.62f, 0.00f, 0.37f, 0.30f},
                {0.46f, 0.00f, 0.53f, 0.20f},
                {0.52f, 0.015f, 0.46f, 0.16f},
                {0.38f, 0.00f, 0.61f, 0.26f},
                {0.00f, 0.00f, 0.56f, 0.30f}
        };
        for (int i = 0; i < boxes.length; i++) {
            float[] b = boxes[i];
            int x = clamp(Math.round(w * b[0]), 0, Math.max(0, w - 1));
            int y = clamp(Math.round(h * b[1]), 0, Math.max(0, h - 1));
            int rw = clamp(Math.round(w * b[2]), 1, w - x);
            int rh = clamp(Math.round(h * b[3]), 1, h - y);
            if (rw < 40 || rh < 40) continue;
            Bitmap crop = null;
            try {
                crop = Bitmap.createBitmap(bitmap, x, y, rw, rh);
                Result r = decodeFastCandidate(crop, i < 3);
                if (isValid(r)) return r;
            } catch (OutOfMemoryError ignored) {
            } catch (Exception ignored) {
            } finally {
                if (crop != null && !crop.isRecycled()) crop.recycle();
            }
        }
        return null;
    }

    private Result decodeFastCandidate(Bitmap bitmap, boolean qrLikely) {
        if (bitmap == null || bitmap.isRecycled()) return null;
        Result r = decoder.decode(bitmap);
        if (isValid(r)) return r;

        Bitmap bordered = null;
        Bitmap scaled = null;
        Bitmap gray = null;
        try {
            bordered = addWhiteBorder(bitmap, Math.max(10, Math.min(bitmap.getWidth(), bitmap.getHeight()) / 35));
            if (bordered != null) {
                r = decoder.decode(bordered);
                if (isValid(r)) return r;
            }

            int maxSide = Math.max(bitmap.getWidth(), bitmap.getHeight());
            int target = qrLikely ? Math.min(1700, Math.max(900, maxSide * 3)) : Math.min(1800, Math.max(1100, maxSide * 2));
            scaled = upscale(bitmap, target);
            if (scaled != null && scaled != bitmap) {
                r = decoder.decode(scaled);
                if (isValid(r)) return r;
            }

            Bitmap base = (scaled != null && scaled != bitmap) ? scaled : bitmap;
            gray = toGrayscale(base, 1.25f);
            if (gray != null) {
                r = decoder.decode(gray);
                if (isValid(r)) return r;
            }
            return null;
        } finally {
            if (gray != null && !gray.isRecycled()) gray.recycle();
            if (scaled != null && scaled != bitmap && !scaled.isRecycled()) scaled.recycle();
            if (bordered != null && bordered != bitmap && !bordered.isRecycled()) bordered.recycle();
        }
    }

    private Result decodeRegions(Bitmap bitmap, boolean manualCrop) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        if (w < 20 || h < 20) return null;

        List<int[]> regions = new ArrayList<>();

        // DANFE/NFS-e: prioridade forte no topo, principalmente canto superior direito.
        addRegion(regions, w, h, 0.00f, 0.00f, 1.00f, 0.42f);
        addRegion(regions, w, h, 0.32f, 0.00f, 0.68f, 0.32f);
        addRegion(regions, w, h, 0.52f, 0.00f, 0.48f, 0.34f);
        addRegion(regions, w, h, 0.66f, 0.00f, 0.34f, 0.30f);
        // QR da NFS-e Nacional costuma ficar pequeno no canto superior direito.
        // As janelas mais estreitas vêm primeiro para receber o tratamento agressivo.
        addRegion(regions, w, h, 0.75f, 0.05f, 0.125f, 0.095f);
        addRegion(regions, w, h, 0.745f, 0.045f, 0.135f, 0.11f);
        addRegion(regions, w, h, 0.70f, 0.025f, 0.27f, 0.20f);
        addRegion(regions, w, h, 0.76f, 0.045f, 0.18f, 0.15f);
        addRegion(regions, w, h, 0.74f, 0.04f, 0.15f, 0.12f);
        // Código de barras DANFE costuma ocupar uma faixa horizontal no topo direito.
        addRegion(regions, w, h, 0.42f, 0.00f, 0.56f, 0.20f);
        addRegion(regions, w, h, 0.00f, 0.00f, 0.58f, 0.34f);
        addRegion(regions, w, h, 0.15f, 0.00f, 0.70f, 0.28f);

        // Quadrantes e faixas laterais.
        addRegion(regions, w, h, 0.00f, 0.00f, 0.52f, 0.52f);
        addRegion(regions, w, h, 0.48f, 0.00f, 0.52f, 0.52f);
        addRegion(regions, w, h, 0.00f, 0.45f, 0.52f, 0.55f);
        addRegion(regions, w, h, 0.48f, 0.45f, 0.52f, 0.55f);
        addRegion(regions, w, h, 0.00f, 0.20f, 1.00f, 0.35f);
        addRegion(regions, w, h, 0.00f, 0.50f, 1.00f, 0.50f);

        // Grade 3 x 4 para códigos fora do padrão de layout.
        int cols = 3, rows = 4;
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                float left = Math.max(0f, col / (float) cols - 0.025f);
                float top = Math.max(0f, row / (float) rows - 0.02f);
                float right = Math.min(1f, (col + 1) / (float) cols + 0.025f);
                float bottom = Math.min(1f, (row + 1) / (float) rows + 0.02f);
                addRegion(regions, w, h, left, top, right - left, bottom - top);
            }
        }

        int priorityCount = manualCrop ? regions.size() : Math.min(regions.size(), 14);
        for (int i = 0; i < priorityCount; i++) {
            int[] r = regions.get(i);
            Bitmap crop = null;
            try {
                crop = Bitmap.createBitmap(bitmap, r[0], r[1], r[2], r[3]);
                // O caminho rápido já tratou os recortes prováveis. Aqui usa tratamento moderado
                // para reduzir latência; o recorte manual continua agressivo.
                int strength = manualCrop ? 3 : (i < 8 ? 2 : 1);
                Result result = decodeCandidate(crop, strength);
                if (isValid(result)) return result;
            } catch (OutOfMemoryError ignored) {
                // Continua com as próximas regiões menores.
            } catch (Exception ignored) {
            } finally {
                if (crop != null && crop != bitmap && !crop.isRecycled()) crop.recycle();
            }
        }
        return null;
    }

    private static void addRegion(List<int[]> out, int w, int h, float fx, float fy, float fw, float fh) {
        int x = clamp(Math.round(w * fx), 0, Math.max(0, w - 1));
        int y = clamp(Math.round(h * fy), 0, Math.max(0, h - 1));
        int rw = clamp(Math.round(w * fw), 1, w - x);
        int rh = clamp(Math.round(h * fh), 1, h - y);
        if (rw >= 24 && rh >= 24) out.add(new int[]{x, y, rw, rh});
    }

    private Result decodeCandidate(Bitmap bitmap, int strength) {
        if (bitmap == null || bitmap.isRecycled()) return null;

        Result r = decoder.decode(bitmap);
        if (isValid(r)) return r;

        Bitmap bordered = null;
        Bitmap scaled = null;
        Bitmap gray = null;
        Bitmap contrast = null;
        Bitmap binary = null;
        try {
            // Quiet-zone: ajuda muito quando o recorte encosta nas barras ou nos marcadores do QR.
            bordered = addWhiteBorder(bitmap, Math.max(12, Math.min(bitmap.getWidth(), bitmap.getHeight()) / 30));
            if (bordered != null) {
                r = decoder.decode(bordered);
                if (isValid(r)) return r;
            }

            // Ampliação seletiva: códigos pequenos na foto inteira passam a ter módulos/barras mais largos.
            if (strength >= 2 || Math.max(bitmap.getWidth(), bitmap.getHeight()) < 1400) {
                int maxSide = Math.max(bitmap.getWidth(), bitmap.getHeight());
                int target = strength >= 3 ? Math.min(2400, Math.max(maxSide + 1, maxSide * 3)) : 1900;
                scaled = upscale(bitmap, target);
                if (scaled != null && scaled != bitmap) {
                    r = decoder.decode(scaled);
                    if (isValid(r)) return r;
                }
            }

            Bitmap base = (scaled != null && scaled != bitmap) ? scaled : bitmap;
            gray = toGrayscale(base, 1.0f);
            if (gray != null) {
                r = decoder.decode(gray);
                if (isValid(r)) return r;
            }

            if (strength >= 2) {
                contrast = toGrayscale(base, 1.45f);
                if (contrast != null) {
                    r = decoder.decode(contrast);
                    if (isValid(r)) return r;
                }

                if (strength >= 3) {
                    int[] rgbThresholds = new int[]{70, 80, 95, 110};
                    for (int t : rgbThresholds) {
                        binary = thresholdRgbChannels(base, t);
                        if (binary != null) {
                            r = decoder.decode(binary);
                            if (isValid(r)) return r;
                            binary.recycle();
                            binary = null;
                        }
                    }
                }

                int[] thresholds = strength >= 3 ? new int[]{80, 105, 130, 155, 180, 205} : new int[]{95, 125, 160, 190};
                for (int threshold : thresholds) {
                    binary = threshold(gray != null ? gray : base, threshold);
                    if (binary != null) {
                        r = decoder.decode(binary);
                        if (isValid(r)) return r;
                        binary.recycle();
                        binary = null;
                    }
                }
            }
            return null;
        } catch (OutOfMemoryError ignored) {
            return null;
        } finally {
            if (binary != null && !binary.isRecycled()) binary.recycle();
            if (contrast != null && !contrast.isRecycled()) contrast.recycle();
            if (gray != null && !gray.isRecycled()) gray.recycle();
            if (scaled != null && scaled != bitmap && !scaled.isRecycled()) scaled.recycle();
            if (bordered != null && bordered != bitmap && !bordered.isRecycled()) bordered.recycle();
        }
    }

    private static Bitmap upscale(Bitmap source, int targetMaxSide) {
        int w = source.getWidth();
        int h = source.getHeight();
        int max = Math.max(w, h);
        if (max <= 0 || max >= targetMaxSide) return source;
        float factor = Math.min(4.0f, targetMaxSide / (float) max);
        if (factor < 1.20f) return source;
        long pixels = Math.round(w * factor) * (long) Math.round(h * factor);
        if (pixels > 5_500_000L) {
            factor = (float) Math.sqrt(5_500_000.0 / Math.max(1.0, w * (double) h));
        }
        if (factor < 1.15f) return source;
        return Bitmap.createScaledBitmap(source, Math.max(1, Math.round(w * factor)), Math.max(1, Math.round(h * factor)), true);
    }

    private static Bitmap addWhiteBorder(Bitmap source, int border) {
        if (border <= 0) return null;
        int w = source.getWidth() + border * 2;
        int h = source.getHeight() + border * 2;
        if ((long) w * h > 6_000_000L) return null;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(source, border, border, null);
        return out;
    }

    private static Bitmap toGrayscale(Bitmap source, float contrastFactor) {
        int w = source.getWidth(), h = source.getHeight();
        if ((long) w * h > 6_000_000L) return null;
        int[] pixels = new int[w * h];
        source.getPixels(pixels, 0, w, 0, 0, w, h);
        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            int gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
            if (contrastFactor != 1.0f) {
                gray = clamp(Math.round((gray - 128) * contrastFactor + 128), 0, 255);
            }
            pixels[i] = Color.rgb(gray, gray, gray);
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(pixels, 0, w, 0, 0, w, h);
        return out;
    }

    private static Bitmap thresholdRgbChannels(Bitmap source, int threshold) {
        int w = source.getWidth(), h = source.getHeight();
        if ((long) w * h > 6_000_000L) return null;
        int[] pixels = new int[w * h];
        source.getPixels(pixels, 0, w, 0, 0, w, h);
        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            int r = Color.red(c) < threshold ? 0 : 255;
            int g = Color.green(c) < threshold ? 0 : 255;
            int b = Color.blue(c) < threshold ? 0 : 255;
            pixels[i] = Color.rgb(r, g, b);
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(pixels, 0, w, 0, 0, w, h);
        return out;
    }

    private static Bitmap threshold(Bitmap source, int threshold) {
        int w = source.getWidth(), h = source.getHeight();
        if ((long) w * h > 6_000_000L) return null;
        int[] pixels = new int[w * h];
        source.getPixels(pixels, 0, w, 0, 0, w, h);
        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            int gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
            int v = gray < threshold ? 0 : 255;
            pixels[i] = Color.rgb(v, v, v);
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(pixels, 0, w, 0, 0, w, h);
        return out;
    }

    private static boolean isValid(Result result) {
        return result != null && isFiscalPayload(result.text, result.format);
    }

    private static Result normalize(Result result) {
        String normalized = EmbeddedScannerController.normalizeFiscalPayloadForExternal(result.text, result.format);
        return normalized.isEmpty() ? null : new Result(normalized, result.format);
    }

    private static boolean isFiscalPayload(String text, String format) {
        return !EmbeddedScannerController.normalizeFiscalPayloadForExternal(text, format).isEmpty();
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static final class BitmapZxingDecoder {
        private Object reader;
        private Constructor<?> rgbCtor;
        private Constructor<?> hybridCtor;
        private Constructor<?> globalCtor;
        private Constructor<?> bitmapCtor;
        private Method decodeMethod;
        private Method resetMethod;
        private Method getTextMethod;
        private Method getFormatMethod;
        private boolean available;

        @SuppressWarnings({"unchecked", "rawtypes"})
        BitmapZxingDecoder() {
            try {
                Class<?> luminance = Class.forName("com.google.zxing.LuminanceSource");
                Class<?> binarizer = Class.forName("com.google.zxing.Binarizer");
                Class<?> binaryBitmap = Class.forName("com.google.zxing.BinaryBitmap");
                Class<?> rgb = Class.forName("com.google.zxing.RGBLuminanceSource");
                Class<?> hybrid = Class.forName("com.google.zxing.common.HybridBinarizer");
                Class<?> global = null;
                try { global = Class.forName("com.google.zxing.common.GlobalHistogramBinarizer"); } catch (Exception ignored) {}
                Class<?> readerClass = Class.forName("com.google.zxing.MultiFormatReader");
                Class<?> resultClass = Class.forName("com.google.zxing.Result");
                Class<?> hintClass = Class.forName("com.google.zxing.DecodeHintType");
                Class<?> formatClass = Class.forName("com.google.zxing.BarcodeFormat");

                rgbCtor = rgb.getConstructor(int.class, int.class, int[].class);
                hybridCtor = hybrid.getConstructor(luminance);
                if (global != null) globalCtor = global.getConstructor(luminance);
                bitmapCtor = binaryBitmap.getConstructor(binarizer);
                reader = readerClass.getConstructor().newInstance();

                Map<Object, Object> hints = new HashMap<>();
                hints.put(Enum.valueOf((Class<? extends Enum>) hintClass, "TRY_HARDER"), Boolean.TRUE);
                hints.put(Enum.valueOf((Class<? extends Enum>) hintClass, "CHARACTER_SET"), "UTF-8");
                try { hints.put(Enum.valueOf((Class<? extends Enum>) hintClass, "ALSO_INVERTED"), Boolean.TRUE); } catch (Exception ignored) {}
                List<Object> formats = new ArrayList<>();
                String[] wanted = {"CODE_128", "QR_CODE", "DATA_MATRIX", "PDF_417", "AZTEC", "CODE_39", "ITF", "EAN_13", "EAN_8", "CODABAR"};
                for (String name : wanted) {
                    try { formats.add(Enum.valueOf((Class<? extends Enum>) formatClass, name)); } catch (Exception ignored) {}
                }
                hints.put(Enum.valueOf((Class<? extends Enum>) hintClass, "POSSIBLE_FORMATS"), formats);
                try { readerClass.getMethod("setHints", Map.class).invoke(reader, hints); } catch (Exception ignored) {}
                try { decodeMethod = readerClass.getMethod("decodeWithState", binaryBitmap); }
                catch (Exception e) { decodeMethod = readerClass.getMethod("decode", binaryBitmap); }
                resetMethod = readerClass.getMethod("reset");
                getTextMethod = resultClass.getMethod("getText");
                getFormatMethod = resultClass.getMethod("getBarcodeFormat");
                available = true;
            } catch (Exception ignored) {
                available = false;
            }
        }

        Result decode(Bitmap bitmap) {
            if (!available || bitmap == null || bitmap.isRecycled()) return null;
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            if (width <= 0 || height <= 0 || (long) width * height > 6_500_000L) return null;
            try {
                int[] pixels = new int[width * height];
                bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
                Object source = rgbCtor.newInstance(width, height, pixels);

                Result result = decodeWithBinarizer(source, hybridCtor);
                if (result != null) return result;
                if (globalCtor != null) return decodeWithBinarizer(source, globalCtor);
                return null;
            } catch (Throwable ignored) {
                try { resetMethod.invoke(reader); } catch (Exception ignored2) {}
                return null;
            }
        }

        private Result decodeWithBinarizer(Object source, Constructor<?> ctor) {
            try {
                Object binarizer = ctor.newInstance(source);
                Object binaryBitmap = bitmapCtor.newInstance(binarizer);
                Object result = decodeMethod.invoke(reader, binaryBitmap);
                String text = String.valueOf(getTextMethod.invoke(result));
                String format = String.valueOf(getFormatMethod.invoke(result));
                try { resetMethod.invoke(reader); } catch (Exception ignored) {}
                return new Result(text, format);
            } catch (Throwable ignored) {
                try { resetMethod.invoke(reader); } catch (Exception ignored2) {}
                return null;
            }
        }
    }
}
