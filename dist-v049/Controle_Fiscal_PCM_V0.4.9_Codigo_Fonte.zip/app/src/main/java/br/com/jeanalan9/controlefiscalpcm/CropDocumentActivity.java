package br.com.jeanalan9.controlefiscalpcm;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Fallback manual da V0.4.8: quando a leitura automática falhar, o usuário pode
 * marcar somente a área do QR Code/código de barras. O recorte volta ao mesmo
 * motor de leitura fiscal, sem salvar a imagem no aplicativo.
 */
public class CropDocumentActivity extends Activity {
    public static final String EXTRA_URI = "document_uri";
    public static final String EXTRA_RAW = "decoded_raw";
    public static final String EXTRA_FORMAT = "decoded_format";

    private CropView cropView;
    private Bitmap sourceBitmap;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Button readButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.BLACK);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        String uriString = getIntent().getStringExtra(EXTRA_URI);
        if (uriString == null || uriString.trim().isEmpty()) {
            Toast.makeText(this, "Arquivo não informado.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        try {
            sourceBitmap = loadPreview(Uri.parse(uriString));
        } catch (Exception e) {
            sourceBitmap = null;
        }
        if (sourceBitmap == null) {
            Toast.makeText(this, "Não foi possível abrir a imagem para recorte.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244, 247, 246));
        root.setPadding(dp(14), dp(10), dp(14), dp(12));

        TextView title = new TextView(this);
        title.setText("Selecionar área do código");
        title.setTextColor(Color.rgb(21, 33, 30));
        title.setTextSize(21);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new TextView(this);
        subtitle.setText("Arraste o dedo formando um retângulo ao redor do QR Code ou código de barras.");
        subtitle.setTextColor(Color.rgb(105, 119, 114));
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(3), 0, dp(9));
        root.addView(subtitle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        cropView = new CropView(this, sourceBitmap);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(cropView, imageParams);

        TextView hint = new TextView(this);
        hint.setText("Dica: deixe uma pequena margem branca ao redor do código.");
        hint.setTextColor(Color.rgb(119, 130, 126));
        hint.setTextSize(10);
        hint.setPadding(dp(2), dp(8), dp(2), dp(8));
        root.addView(hint, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);

        Button cancel = new Button(this);
        cancel.setText("CANCELAR");
        cancel.setTextSize(11);
        cancel.setAllCaps(false);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setResult(RESULT_CANCELED); finish(); }
        });

        readButton = new Button(this);
        readButton.setText("LER ÁREA SELECIONADA");
        readButton.setTextSize(11);
        readButton.setAllCaps(false);
        readButton.setTextColor(Color.WHITE);
        readButton.setBackgroundColor(Color.rgb(10, 174, 125));
        readButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { decodeSelection(); }
        });

        buttons.addView(cancel, new LinearLayout.LayoutParams(0, dp(46), 0.34f));
        LinearLayout.LayoutParams readParams = new LinearLayout.LayoutParams(0, dp(46), 0.66f);
        readParams.leftMargin = dp(8);
        buttons.addView(readButton, readParams);
        root.addView(buttons, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private void decodeSelection() {
        final Bitmap crop = cropView.createSelectedCrop();
        if (crop == null) {
            Toast.makeText(this, "Marque a área do código antes de continuar.", Toast.LENGTH_SHORT).show();
            return;
        }
        readButton.setEnabled(false);
        readButton.setText("LENDO...");
        executor.execute(new Runnable() {
            @Override public void run() {
                ImportedDocumentDecoder.Result result = null;
                try {
                    result = new ImportedDocumentDecoder(CropDocumentActivity.this).decodeBitmap(crop);
                } catch (Exception ignored) {}
                if (!crop.isRecycled()) crop.recycle();
                final ImportedDocumentDecoder.Result finalResult = result;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        readButton.setEnabled(true);
                        readButton.setText("LER ÁREA SELECIONADA");
                        if (finalResult == null || finalResult.text == null || finalResult.text.trim().isEmpty()) {
                            Toast.makeText(CropDocumentActivity.this,
                                    "Código não identificado nessa área. Tente marcar mais perto do código, mantendo uma pequena margem.",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        android.content.Intent data = new android.content.Intent();
                        data.putExtra(EXTRA_RAW, finalResult.text);
                        data.putExtra(EXTRA_FORMAT, finalResult.format);
                        setResult(RESULT_OK, data);
                        finish();
                    }
                });
            }
        });
    }

    private Bitmap loadPreview(Uri uri) throws Exception {
        String mime = getContentResolver().getType(uri);
        if (mime != null && mime.toLowerCase().contains("pdf")) return renderPdfFirstPage(uri);

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        InputStream p = null;
        try {
            p = getContentResolver().openInputStream(uri);
            if (p != null) BitmapFactory.decodeStream(p, null, bounds);
        } finally {
            if (p != null) try { p.close(); } catch (Exception ignored) {}
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            try { return renderPdfFirstPage(uri); } catch (Exception ignored) { return null; }
        }
        int sample = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / sample > 2600) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        InputStream in = null;
        try {
            in = getContentResolver().openInputStream(uri);
            return in == null ? null : BitmapFactory.decodeStream(in, null, opts);
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) {}
        }
    }

    private Bitmap renderPdfFirstPage(Uri uri) throws Exception {
        ParcelFileDescriptor fd = null;
        PdfRenderer renderer = null;
        PdfRenderer.Page page = null;
        try {
            fd = getContentResolver().openFileDescriptor(uri, "r");
            if (fd == null) return null;
            renderer = new PdfRenderer(fd);
            if (renderer.getPageCount() <= 0) return null;
            page = renderer.openPage(0);
            int sw = Math.max(1, page.getWidth());
            int sh = Math.max(1, page.getHeight());
            float scale = Math.min(3f, 2600f / Math.max(sw, sh));
            if (scale < 1.2f) scale = 1.2f;
            int w = Math.max(1, Math.round(sw * scale));
            int h = Math.max(1, Math.round(sh * scale));
            Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            bitmap.eraseColor(Color.WHITE);
            Matrix matrix = new Matrix();
            matrix.setScale((float) w / sw, (float) h / sh);
            page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            return bitmap;
        } finally {
            if (page != null) try { page.close(); } catch (Exception ignored) {}
            if (renderer != null) try { renderer.close(); } catch (Exception ignored) {}
            if (fd != null) try { fd.close(); } catch (Exception ignored) {}
        }
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (sourceBitmap != null && !sourceBitmap.isRecycled()) sourceBitmap.recycle();
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class CropView extends View {
        private final Bitmap bitmap;
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint shadePaint = new Paint();
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF imageRect = new RectF();
        private final RectF selection = new RectF();
        private float startX, startY;
        private boolean dragging;

        CropView(Activity context, Bitmap bitmap) {
            super(context);
            this.bitmap = bitmap;
            setBackgroundColor(Color.rgb(222, 228, 226));
            shadePaint.setColor(Color.argb(105, 0, 0, 0));
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(context.getResources().getDisplayMetrics().density * 2.2f);
            borderPaint.setColor(Color.rgb(24, 220, 162));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (bitmap == null || bitmap.isRecycled()) return;
            float scale = Math.min(getWidth() / (float) bitmap.getWidth(), getHeight() / (float) bitmap.getHeight());
            float dw = bitmap.getWidth() * scale;
            float dh = bitmap.getHeight() * scale;
            float left = (getWidth() - dw) / 2f;
            float top = (getHeight() - dh) / 2f;
            imageRect.set(left, top, left + dw, top + dh);
            canvas.drawBitmap(bitmap, null, imageRect, imagePaint);

            if (!selection.isEmpty()) {
                canvas.drawRect(imageRect.left, imageRect.top, imageRect.right, selection.top, shadePaint);
                canvas.drawRect(imageRect.left, selection.bottom, imageRect.right, imageRect.bottom, shadePaint);
                canvas.drawRect(imageRect.left, selection.top, selection.left, selection.bottom, shadePaint);
                canvas.drawRect(selection.right, selection.top, imageRect.right, selection.bottom, shadePaint);
                canvas.drawRoundRect(selection, 10f, 10f, borderPaint);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (imageRect.isEmpty()) return true;
            float x = clamp(event.getX(), imageRect.left, imageRect.right);
            float y = clamp(event.getY(), imageRect.top, imageRect.bottom);
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                startX = x; startY = y; selection.set(x, y, x, y); dragging = true; invalidate(); return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE && dragging) {
                selection.set(Math.min(startX, x), Math.min(startY, y), Math.max(startX, x), Math.max(startY, y));
                invalidate(); return true;
            }
            if ((event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) && dragging) {
                dragging = false;
                selection.set(Math.min(startX, x), Math.min(startY, y), Math.max(startX, x), Math.max(startY, y));
                invalidate(); return true;
            }
            return true;
        }

        Bitmap createSelectedCrop() {
            if (selection.width() < 24 || selection.height() < 24 || imageRect.width() <= 0 || imageRect.height() <= 0) return null;
            float sx = bitmap.getWidth() / imageRect.width();
            float sy = bitmap.getHeight() / imageRect.height();
            int x = Math.max(0, Math.round((selection.left - imageRect.left) * sx));
            int y = Math.max(0, Math.round((selection.top - imageRect.top) * sy));
            int right = Math.min(bitmap.getWidth(), Math.round((selection.right - imageRect.left) * sx));
            int bottom = Math.min(bitmap.getHeight(), Math.round((selection.bottom - imageRect.top) * sy));
            int w = right - x, h = bottom - y;
            if (w < 16 || h < 16) return null;
            return Bitmap.createBitmap(bitmap, x, y, w, h);
        }

        private static float clamp(float value, float min, float max) {
            return Math.max(min, Math.min(max, value));
        }
    }
}
