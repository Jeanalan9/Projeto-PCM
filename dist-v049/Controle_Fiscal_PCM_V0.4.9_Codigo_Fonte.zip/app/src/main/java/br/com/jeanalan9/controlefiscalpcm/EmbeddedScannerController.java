package br.com.jeanalan9.controlefiscalpcm;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.Camera;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

@SuppressWarnings("deprecation")
public final class EmbeddedScannerController implements SurfaceHolder.Callback, Camera.PreviewCallback {
    public interface Listener {
        void onResult(String raw, String format);
        void onImportRequested();
        void onCancelled();
        void onError(String message);
    }

    private static final long DECODE_INTERVAL_MS = 105L;

    private final Activity activity;
    private final FrameLayout host;
    private final Listener listener;
    private final FrameLayout overlay;
    private final SurfaceView preview;
    private final SurfaceHolder holder;
    private final TextView status;
    private final TextView torchButton;
    private final AtomicBoolean decoding = new AtomicBoolean(false);
    private final AtomicBoolean finished = new AtomicBoolean(false);
    private final ExecutorService decoderExecutor = Executors.newSingleThreadExecutor();
    private final ZxingDecoder decoder = new ZxingDecoder();

    private Camera camera;
    private boolean surfaceReady;
    private boolean torchOn;
    private int previewWidth;
    private int previewHeight;
    private int displayOrientation = 90;
    private long lastDecodeAt;

    public EmbeddedScannerController(Activity activity, FrameLayout host, Listener listener) {
        this.activity = activity;
        this.host = host;
        this.listener = listener;

        overlay = new FrameLayout(activity);
        overlay.setBackgroundColor(Color.BLACK);
        overlay.setClipChildren(true);
        overlay.setClipToPadding(true);
        overlay.setElevation(dp(2));

        preview = new SurfaceView(activity);
        holder = preview.getHolder();
        holder.addCallback(this);
        overlay.addView(preview, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        overlay.addView(new ScannerGuide(activity), new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        TextView close = smallButton("×");
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(dp(38), dp(38));
        closeLp.gravity = Gravity.TOP | Gravity.START;
        closeLp.leftMargin = dp(10);
        closeLp.topMargin = dp(10);
        overlay.addView(close, closeLp);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { cancel(); }
        });

        torchButton = smallButton("⚡");
        FrameLayout.LayoutParams torchLp = new FrameLayout.LayoutParams(dp(42), dp(38));
        torchLp.gravity = Gravity.TOP | Gravity.END;
        torchLp.rightMargin = dp(10);
        torchLp.topMargin = dp(10);
        overlay.addView(torchButton, torchLp);
        torchButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleTorch(); }
        });

        TextView importButton = new TextView(activity);
        importButton.setText("IMPORTAR");
        importButton.setTextColor(Color.WHITE);
        importButton.setTextSize(10);
        importButton.setGravity(Gravity.CENTER);
        importButton.setPadding(dp(12), 0, dp(12), 0);
        importButton.setBackgroundColor(Color.argb(165, 4, 34, 47));
        FrameLayout.LayoutParams importLp = new FrameLayout.LayoutParams(dp(92), dp(38));
        importLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        importLp.topMargin = dp(10);
        overlay.addView(importButton, importLp);
        importButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestImport(); }
        });

        status = new TextView(activity);
        status.setText("Centralize o código na moldura");
        status.setTextColor(Color.WHITE);
        status.setTextSize(11);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(8), dp(5), dp(8), dp(5));
        status.setBackgroundColor(Color.argb(145, 4, 27, 37));
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(32));
        statusLp.gravity = Gravity.BOTTOM;
        statusLp.leftMargin = dp(12);
        statusLp.rightMargin = dp(12);
        statusLp.bottomMargin = dp(9);
        overlay.addView(status, statusLp);
    }

    public void start(int left, int top, int width, int height) {
        if (finished.get()) return;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Math.max(dp(120), width), Math.max(dp(100), height));
        lp.leftMargin = Math.max(0, left);
        lp.topMargin = Math.max(0, top);
        host.addView(overlay, lp);
        overlay.bringToFront();
    }

    public boolean isActive() {
        return !finished.get() && overlay.getParent() != null;
    }

    public void stopSilently() {
        if (finished.compareAndSet(false, true)) {
            releaseCamera();
            removeOverlay();
            decoderExecutor.shutdownNow();
        }
    }

    public void cancel() {
        if (finished.compareAndSet(false, true)) {
            releaseCamera();
            removeOverlay();
            decoderExecutor.shutdownNow();
            if (listener != null) listener.onCancelled();
        }
    }

    private void requestImport() {
        if (finished.compareAndSet(false, true)) {
            releaseCamera();
            removeOverlay();
            decoderExecutor.shutdownNow();
            if (listener != null) listener.onImportRequested();
        }
    }

    private TextView smallButton(String text) {
        TextView v = new TextView(activity);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(20);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(Color.argb(165, 4, 34, 47));
        return v;
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        startCamera();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (camera == null) return;
        try { camera.stopPreview(); } catch (Exception ignored) {}
        configureCamera(camera);
        try {
            camera.setPreviewDisplay(holder);
            camera.setPreviewCallback(this);
            camera.startPreview();
        } catch (Exception e) {
            fail("Não foi possível reiniciar a câmera.");
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        releaseCamera();
    }

    private void startCamera() {
        if (!surfaceReady || camera != null || finished.get()) return;
        try {
            camera = Camera.open();
            configureCamera(camera);
            camera.setPreviewDisplay(holder);
            camera.setPreviewCallback(this);
            camera.startPreview();
        } catch (Exception e) {
            fail("Não foi possível acessar a câmera.");
        }
    }

    private void configureCamera(Camera cam) {
        try {
            Camera.Parameters p = cam.getParameters();
            Camera.Size selected = choosePreviewSize(p.getSupportedPreviewSizes());
            if (selected != null) {
                p.setPreviewSize(selected.width, selected.height);
                previewWidth = selected.width;
                previewHeight = selected.height;
            } else if (p.getPreviewSize() != null) {
                previewWidth = p.getPreviewSize().width;
                previewHeight = p.getPreviewSize().height;
            }

            List<String> scenes = p.getSupportedSceneModes();
            if (scenes != null && scenes.contains(Camera.Parameters.SCENE_MODE_BARCODE)) {
                p.setSceneMode(Camera.Parameters.SCENE_MODE_BARCODE);
            }
            List<String> focusModes = p.getSupportedFocusModes();
            if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            } else if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            } else if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            }

            List<int[]> ranges = p.getSupportedPreviewFpsRange();
            if (ranges != null && !ranges.isEmpty()) {
                int[] best = ranges.get(0);
                for (int[] r : ranges) {
                    if (r != null && r.length > 1 && r[1] > best[1]) best = r;
                }
                p.setPreviewFpsRange(best[0], best[1]);
            }
            cam.setParameters(p);
            displayOrientation = calculateDisplayOrientation();
            cam.setDisplayOrientation(displayOrientation);
        } catch (Exception ignored) {}
    }

    private Camera.Size choosePreviewSize(List<Camera.Size> sizes) {
        if (sizes == null || sizes.isEmpty()) return null;
        Camera.Size best = null;
        long bestScore = Long.MAX_VALUE;
        long target = 1280L * 720L;
        for (Camera.Size s : sizes) {
            long area = (long) s.width * s.height;
            if (area < 640L * 480L) continue;
            long score = Math.abs(area - target);
            if (area > 1920L * 1080L) score += area;
            if (score < bestScore) {
                best = s;
                bestScore = score;
            }
        }
        return best != null ? best : sizes.get(0);
    }

    private int calculateDisplayOrientation() {
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(0, info);
        int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
        int degrees = 0;
        if (rotation == Surface.ROTATION_90) degrees = 90;
        else if (rotation == Surface.ROTATION_180) degrees = 180;
        else if (rotation == Surface.ROTATION_270) degrees = 270;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            int result = (info.orientation + degrees) % 360;
            return (360 - result) % 360;
        }
        return (info.orientation - degrees + 360) % 360;
    }

    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        if (finished.get() || data == null || previewWidth <= 0 || previewHeight <= 0) return;
        long now = System.currentTimeMillis();
        if (now - lastDecodeAt < DECODE_INTERVAL_MS || !decoding.compareAndSet(false, true)) return;
        lastDecodeAt = now;
        int ySize = previewWidth * previewHeight;
        if (data.length < ySize) {
            decoding.set(false);
            return;
        }
        byte[] luminance = new byte[ySize];
        System.arraycopy(data, 0, luminance, 0, ySize);
        final int width = previewWidth;
        final int height = previewHeight;
        final int orientation = displayOrientation;

        decoderExecutor.execute(new Runnable() {
            @Override public void run() {
            try {
                ScanResult result = decoder.decode(luminance, width, height, orientation);
                if (result != null && result.text != null) {
                    String normalized = normalizeFiscalPayload(result.text, result.format);
                    if (!normalized.isEmpty() && finished.compareAndSet(false, true)) {
                        activity.runOnUiThread(new Runnable() {
                            @Override public void run() { finishResult(normalized, result.format); }
                        });
                    }
                }
            } finally {
                decoding.set(false);
            }
            }
        });
    }

    private void finishResult(String raw, String format) {
        try {
            new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 65)
                    .startTone(ToneGenerator.TONE_PROP_BEEP, 100);
        } catch (Exception ignored) {}
        releaseCamera();
        removeOverlay();
        decoderExecutor.shutdownNow();
        if (listener != null) listener.onResult(raw, format == null ? "" : format);
    }

    private void fail(String message) {
        if (finished.compareAndSet(false, true)) {
            releaseCamera();
            removeOverlay();
            decoderExecutor.shutdownNow();
            if (listener != null) listener.onError(message);
        }
    }

    private void removeOverlay() {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                try { host.removeView(overlay); } catch (Exception ignored) {}
            }
        });
    }

    private void toggleTorch() {
        if (camera == null) return;
        try {
            Camera.Parameters p = camera.getParameters();
            List<String> modes = p.getSupportedFlashModes();
            if (modes == null || !modes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                status.setText("Lanterna indisponível");
                return;
            }
            torchOn = !torchOn;
            p.setFlashMode(torchOn ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(p);
            torchButton.setText(torchOn ? "●" : "⚡");
        } catch (Exception ignored) {}
    }

    private void releaseCamera() {
        Camera c = camera;
        camera = null;
        if (c != null) {
            try { c.setPreviewCallback(null); } catch (Exception ignored) {}
            try { c.stopPreview(); } catch (Exception ignored) {}
            try { c.release(); } catch (Exception ignored) {}
        }
    }

    private int dp(int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    static String normalizeFiscalPayloadForExternal(String text, String format) {
        return normalizeFiscalPayload(text, format);
    }

    private static String normalizeFiscalPayload(String text, String format) {
        if (text == null) return "";
        String t = text.trim();
        if (t.isEmpty()) return "";
        String nfe = extractValidNfeKey(t);
        if (!nfe.isEmpty()) return nfe;
        String low = t.toLowerCase();
        if ((low.startsWith("http://") || low.startsWith("https://")) &&
                (low.contains("nf") || low.contains("fazenda") || low.contains("gov.br") || low.contains("nota"))) {
            return t;
        }
        String f = format == null ? "" : format.toUpperCase();
        if ((f.contains("QR") || f.contains("DATA_MATRIX") || f.contains("PDF_417") || f.contains("AZTEC")) && t.length() >= 12) {
            return t;
        }
        return "";
    }

    private static String extractValidNfeKey(String raw) {
        String digits = raw == null ? "" : raw.replaceAll("\\D", "");
        if (digits.length() < 44) return "";
        if (digits.length() == 44 && isValidNfeKey(digits)) return digits;
        for (int i = 0; i + 44 <= digits.length(); i++) {
            String c = digits.substring(i, i + 44);
            if (isValidNfeKey(c) && ("55".equals(c.substring(20, 22)) || "65".equals(c.substring(20, 22)))) return c;
        }
        return "";
    }

    private static boolean isValidNfeKey(String key) {
        if (key == null || key.length() != 44 || !key.matches("\\d{44}")) return false;
        int sum = 0;
        int weight = 2;
        for (int i = 42; i >= 0; i--) {
            sum += Character.digit(key.charAt(i), 10) * weight;
            weight++;
            if (weight > 9) weight = 2;
        }
        int remainder = sum % 11;
        int dv = 11 - remainder;
        if (dv == 10 || dv == 11) dv = 0;
        return dv == Character.digit(key.charAt(43), 10);
    }

    private static final class ScanResult {
        final String text;
        final String format;
        ScanResult(String text, String format) { this.text = text; this.format = format; }
    }

    private static final class ZxingDecoder {
        private Object reader;
        private Constructor<?> sourceCtor;
        private Constructor<?> hybridCtor;
        private Constructor<?> bitmapCtor;
        private Method decodeMethod;
        private Method resetMethod;
        private Method getTextMethod;
        private Method getFormatMethod;
        private boolean available;

        @SuppressWarnings({"unchecked", "rawtypes"})
        ZxingDecoder() {
            try {
                Class<?> luminance = Class.forName("com.google.zxing.LuminanceSource");
                Class<?> binarizer = Class.forName("com.google.zxing.Binarizer");
                Class<?> bitmap = Class.forName("com.google.zxing.BinaryBitmap");
                Class<?> planar = Class.forName("com.google.zxing.PlanarYUVLuminanceSource");
                Class<?> hybrid = Class.forName("com.google.zxing.common.HybridBinarizer");
                Class<?> readerClass = Class.forName("com.google.zxing.MultiFormatReader");
                Class<?> resultClass = Class.forName("com.google.zxing.Result");
                Class<?> hintClass = Class.forName("com.google.zxing.DecodeHintType");
                Class<?> formatClass = Class.forName("com.google.zxing.BarcodeFormat");
                sourceCtor = planar.getConstructor(byte[].class, int.class, int.class,
                        int.class, int.class, int.class, int.class, boolean.class);
                hybridCtor = hybrid.getConstructor(luminance);
                bitmapCtor = bitmap.getConstructor(binarizer);
                reader = readerClass.getConstructor().newInstance();
                Map<Object, Object> hints = new HashMap<>();
                hints.put(Enum.valueOf((Class<? extends Enum>) hintClass, "TRY_HARDER"), Boolean.TRUE);
                hints.put(Enum.valueOf((Class<? extends Enum>) hintClass, "CHARACTER_SET"), "UTF-8");
                List<Object> formats = new ArrayList<>();
                String[] wanted = {"CODE_128", "QR_CODE", "DATA_MATRIX", "PDF_417", "AZTEC", "CODE_39", "ITF", "EAN_13"};
                for (String name : wanted) {
                    try { formats.add(Enum.valueOf((Class<? extends Enum>) formatClass, name)); } catch (Exception ignored) {}
                }
                hints.put(Enum.valueOf((Class<? extends Enum>) hintClass, "POSSIBLE_FORMATS"), formats);
                try { readerClass.getMethod("setHints", Map.class).invoke(reader, hints); } catch (Exception ignored) {}
                try { decodeMethod = readerClass.getMethod("decodeWithState", bitmap); }
                catch (Exception e) { decodeMethod = readerClass.getMethod("decode", bitmap); }
                resetMethod = readerClass.getMethod("reset");
                getTextMethod = resultClass.getMethod("getText");
                getFormatMethod = resultClass.getMethod("getBarcodeFormat");
                available = true;
            } catch (Exception e) {
                available = false;
            }
        }

        ScanResult decode(byte[] y, int width, int height, int orientation) {
            if (!available) return null;
            if (orientation == 90 || orientation == 270) {
                byte[] rotated = orientation == 90 ? rotate90(y, width, height) : rotate270(y, width, height);
                int rw = height, rh = width;
                ScanResult r = decodeCenterRegion(rotated, rw, rh);
                if (r != null) return r;
                r = decodeOnce(rotated, rw, rh, 0, 0, rw, rh);
                if (r != null) return r;
                return decodeCenterRegion(y, width, height);
            }
            ScanResult r = decodeCenterRegion(y, width, height);
            return r != null ? r : decodeOnce(y, width, height, 0, 0, width, height);
        }

        private ScanResult decodeCenterRegion(byte[] y, int width, int height) {
            int left = Math.max(0, Math.round(width * .04f));
            int top = Math.max(0, Math.round(height * .16f));
            int cw = Math.min(width - left, Math.round(width * .92f));
            int ch = Math.min(height - top, Math.round(height * .62f));
            return decodeOnce(y, width, height, left, top, cw, ch);
        }

        private ScanResult decodeOnce(byte[] y, int width, int height, int left, int top, int cropW, int cropH) {
            try {
                if (cropW <= 0 || cropH <= 0 || left < 0 || top < 0 || left + cropW > width || top + cropH > height) return null;
                Object source = sourceCtor.newInstance(y, width, height, left, top, cropW, cropH, false);
                Object hybrid = hybridCtor.newInstance(source);
                Object bitmap = bitmapCtor.newInstance(hybrid);
                Object result = decodeMethod.invoke(reader, bitmap);
                String text = String.valueOf(getTextMethod.invoke(result));
                Object format = getFormatMethod.invoke(result);
                try { resetMethod.invoke(reader); } catch (Exception ignored) {}
                return new ScanResult(text, String.valueOf(format));
            } catch (Exception ignored) {
                try { resetMethod.invoke(reader); } catch (Exception ignored2) {}
                return null;
            }
        }

        private static byte[] rotate90(byte[] data, int width, int height) {
            byte[] rotated = new byte[width * height];
            int index = 0;
            for (int x = 0; x < width; x++) for (int y = height - 1; y >= 0; y--) rotated[index++] = data[y * width + x];
            return rotated;
        }

        private static byte[] rotate270(byte[] data, int width, int height) {
            byte[] rotated = new byte[width * height];
            int index = 0;
            for (int x = width - 1; x >= 0; x--) for (int y = 0; y < height; y++) rotated[index++] = data[y * width + x];
            return rotated;
        }
    }

    private static final class ScannerGuide extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        ScannerGuide(android.content.Context context) {
            super(context);
            line.setStrokeWidth(dpStatic(context, 2));
            line.setColor(Color.rgb(41, 215, 158));
            line.setShadowLayer(dpStatic(context, 7), 0, 0, Color.rgb(41, 215, 158));
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        @Override protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            float boxW = w * .80f;
            float boxH = Math.min(h * .44f, boxW * .54f);
            float left = (w - boxW) / 2f;
            float top = (h - boxH) / 2f;
            RectF box = new RectF(left, top, left + boxW, top + boxH);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpStatic(getContext(), 2));
            paint.setColor(Color.argb(225, 230, 240, 237));
            canvas.drawRoundRect(box, dpStatic(getContext(), 18), dpStatic(getContext(), 18), paint);
            canvas.drawLine(box.left + dpStatic(getContext(), 16), box.centerY(), box.right - dpStatic(getContext(), 16), box.centerY(), line);
        }
        private static int dpStatic(android.content.Context c, int value) {
            return Math.round(value * c.getResources().getDisplayMetrics().density);
        }
    }
}
