package br.com.jeanalan9.controlefiscalpcm;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_FISCAL_LOOKUP = 9202;
    private static final int REQUEST_CAMERA = 9203;
    private static final int REQUEST_IMPORT_DOCUMENT = 9204;
    private static final int REQUEST_MANUAL_CROP = 9205;

    private WebView webView;
    private FrameLayout root;
    private EmbeddedScannerController embeddedScanner;
    private final ExecutorService importExecutor = Executors.newSingleThreadExecutor();
    private Uri lastImportedUri;
    private int pendingX, pendingY, pendingW, pendingH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.setClipToPadding(true);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 247, 246));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(this), "AndroidPCM");

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int topInset;
                int bottomInset;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Insets safe = insets.getInsets(
                            WindowInsets.Type.statusBars()
                                    | WindowInsets.Type.navigationBars()
                                    | WindowInsets.Type.displayCutout());
                    topInset = safe.top;
                    bottomInset = safe.bottom;
                } else {
                    topInset = insets.getSystemWindowInsetTop();
                    bottomInset = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(0, topInset, 0, bottomInset);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return WindowInsets.CONSUMED;
                return insets.consumeSystemWindowInsets();
            }
        });

        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
        root.requestApplyInsets();
    }

    public void iniciarScannerEmbutido(int x, int y, int width, int height) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
            pendingX = x;
            pendingY = y;
            pendingW = width;
            pendingH = height;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
                return;
            }
            abrirScannerEmbutido();
            }
        });
    }

    private void abrirScannerEmbutido() {
        if (root == null || webView == null) return;
        if (embeddedScanner != null && embeddedScanner.isActive()) embeddedScanner.stopSilently();

        int left = webView.getLeft() + Math.max(0, pendingX);
        int top = webView.getTop() + Math.max(0, pendingY);
        int maxW = Math.max(1, root.getWidth() - left - root.getPaddingRight());
        int maxH = Math.max(1, root.getHeight() - top - root.getPaddingBottom());
        int width = Math.min(Math.max(1, pendingW), maxW);
        int height = Math.min(Math.max(1, pendingH), maxH);

        embeddedScanner = new EmbeddedScannerController(this, root, new EmbeddedScannerController.Listener() {
            @Override public void onResult(String raw, String format) {
                embeddedScanner = null;
                final String js = "if(window.onNativeScanResult){window.onNativeScanResult(" +
                        JSONObject.quote(raw == null ? "" : raw) + "," +
                        JSONObject.quote(format == null ? "" : format) + ");}";
                webView.evaluateJavascript(js, null);
            }
            @Override public void onImportRequested() {
                embeddedScanner = null;
                iniciarImportacaoDocumento();
            }
            @Override public void onCancelled() {
                embeddedScanner = null;
                webView.evaluateJavascript("if(window.onNativeScanCancelled){window.onNativeScanCancelled();}", null);
            }
            @Override public void onError(String message) {
                embeddedScanner = null;
                final String js = "if(window.onNativeScanError){window.onNativeScanError(" + JSONObject.quote(message) + ");}";
                webView.evaluateJavascript(js, null);
            }
        });
        embeddedScanner.start(left, top, width, height);
    }


    public void iniciarImportacaoDocumento() {
        if (webView != null) {
            webView.evaluateJavascript("if(window.onNativeImportStarted){window.onNativeImportStarted();}", null);
        }
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf"});
            startActivityForResult(intent, REQUEST_IMPORT_DOCUMENT);
        } catch (Exception e) {
            if (webView != null) {
                webView.evaluateJavascript("if(window.onNativeScanError){window.onNativeScanError('Não foi possível abrir os arquivos do telefone.');}", null);
            }
        }
    }

    private void processarDocumentoImportado(final Uri uri) {
        if (uri == null) return;
        lastImportedUri = uri;
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        if (webView != null) {
            webView.evaluateJavascript("if(window.onNativeImportProcessing){window.onNativeImportProcessing();}", null);
        }
        importExecutor.execute(new Runnable() {
            @Override public void run() {
                try {
                    final ImportedDocumentDecoder.Result result = new ImportedDocumentDecoder(MainActivity.this).decode(uri);
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (webView == null) return;
                            String js = "if(window.onNativeScanResult){window.onNativeScanResult(" +
                                    JSONObject.quote(result.text) + "," + JSONObject.quote(result.format) + ");}";
                            webView.evaluateJavascript(js, null);
                        }
                    });
                    // O código é devolvido imediatamente. O OCR da NFS-e é enfileirado em
                    // seguida e completa os campos sem bloquear a importação principal.
                    iniciarOcrNfseImportada(uri, result.text);
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (webView == null) return;
                            String message = e.getMessage();
                            if (message == null || message.trim().isEmpty()) {
                                message = "Não conseguimos identificar automaticamente o QR Code ou código de barras fiscal neste arquivo.";
                            }
                            String js = "if(window.onNativeImportFailed){window.onNativeImportFailed(" + JSONObject.quote(message) + ");}";
                            webView.evaluateJavascript(js, null);
                        }
                    });
                }
            }
        });
    }


    private void iniciarOcrNfseImportada(final Uri uri, final String raw) {
        if (uri == null || raw == null || raw.trim().isEmpty()) return;
        final AppBridge.FiscalScanData parsed = AppBridge.analyzeRaw(raw);
        if (!"NFSE".equals(parsed.consultaTipo)) return;

        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (webView != null) {
                    webView.evaluateJavascript("if(window.onNativeImportedOcrStarted){window.onNativeImportedOcrStarted();}", null);
                }
            }
        });

        importExecutor.execute(new Runnable() {
            @Override public void run() {
                JSONObject payload;
                try {
                    payload = new ImportedFiscalOcr(MainActivity.this).recognize(uri, parsed.cnpj, parsed.numero);
                } catch (Exception e) {
                    payload = new JSONObject();
                    try {
                        payload.put("ok", false);
                        payload.put("completo", false);
                        payload.put("error", e.getMessage() == null ? "Não foi possível completar automaticamente os dados da NFS-e pelo documento." : e.getMessage());
                    } catch (Exception ignored) {}
                }
                final String json = payload.toString();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (webView == null) return;
                        webView.evaluateJavascript("if(window.onNativeImportedFiscalData){window.onNativeImportedFiscalData(" + json + ");}", null);
                    }
                });
            }
        });
    }

    public void iniciarRecorteManualUltimoArquivo() {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (lastImportedUri == null) {
                    if (webView != null) webView.evaluateJavascript("if(window.onNativeImportFailed){window.onNativeImportFailed('Importe uma imagem ou PDF antes de selecionar a área manualmente.');}", null);
                    return;
                }
                try {
                    Intent intent = new Intent(MainActivity.this, CropDocumentActivity.class);
                    intent.putExtra(CropDocumentActivity.EXTRA_URI, lastImportedUri.toString());
                    startActivityForResult(intent, REQUEST_MANUAL_CROP);
                } catch (Exception e) {
                    if (webView != null) webView.evaluateJavascript("if(window.onNativeImportFailed){window.onNativeImportFailed('Não foi possível abrir o recorte manual.');}", null);
                }
            }
        });
    }

    public void iniciarConsultaFiscal(String key, String type, String rawUrl) {
        final String cleanType = type == null ? "NFE" : type.trim().toUpperCase(Locale.ROOT);
        final String cleanKey;
        if ("NFSE".equals(cleanType)) cleanKey = key == null ? "" : key.replaceAll("[^0-9A-Za-z]", "");
        else cleanKey = key == null ? "" : key.replaceAll("\\D", "");
        runOnUiThread(new Runnable() {
            @Override public void run() {
            Intent intent = new Intent(MainActivity.this, ConsultaNfeActivity.class);
            intent.putExtra(ConsultaNfeActivity.EXTRA_KEY, cleanKey);
            intent.putExtra(ConsultaNfeActivity.EXTRA_TYPE, cleanType);
            intent.putExtra(ConsultaNfeActivity.EXTRA_RAW_URL, rawUrl == null ? "" : rawUrl);
            startActivityForResult(intent, REQUEST_FISCAL_LOOKUP);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                abrirScannerEmbutido();
            } else {
                webView.evaluateJavascript("if(window.onNativeScanError){window.onNativeScanError('Permissão da câmera negada.');}", null);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMPORT_DOCUMENT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                processarDocumentoImportado(data.getData());
            } else if (webView != null) {
                webView.evaluateJavascript("if(window.onNativeImportCancelled){window.onNativeImportCancelled();}", null);
            }
            return;
        }
        if (requestCode == REQUEST_MANUAL_CROP) {
            if (resultCode == RESULT_OK && data != null) {
                String raw = data.getStringExtra(CropDocumentActivity.EXTRA_RAW);
                String format = data.getStringExtra(CropDocumentActivity.EXTRA_FORMAT);
                if (raw == null) raw = "";
                if (format == null) format = "";
                final String js = "if(window.onNativeScanResult){window.onNativeScanResult(" + JSONObject.quote(raw) + "," + JSONObject.quote(format) + ");}";
                if (webView != null) webView.evaluateJavascript(js, null);
                iniciarOcrNfseImportada(lastImportedUri, raw);
            } else if (webView != null) {
                webView.evaluateJavascript("if(window.onNativeImportManualCancelled){window.onNativeImportManualCancelled();}", null);
            }
            return;
        }
        if (requestCode == REQUEST_FISCAL_LOOKUP) {
            if (resultCode == RESULT_OK && data != null) {
                String json = data.getStringExtra(ConsultaNfeActivity.EXTRA_RESULT_JSON);
                if (json == null || json.trim().isEmpty()) json = "{}";
                final String js = "if(window.onNativeFiscalLookupResult){window.onNativeFiscalLookupResult(" + json + ");}";
                webView.evaluateJavascript(js, null);
            } else {
                String error = data == null ? "Consulta cancelada." : data.getStringExtra(ConsultaNfeActivity.EXTRA_ERROR);
                if (error == null || error.trim().isEmpty()) error = "Consulta cancelada.";
                final String js = "if(window.onNativeFiscalLookupCancelled){window.onNativeFiscalLookupCancelled(" + JSONObject.quote(error) + ");}";
                webView.evaluateJavascript(js, null);
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onPause() {
        if (embeddedScanner != null && embeddedScanner.isActive()) {
            embeddedScanner.stopSilently();
            embeddedScanner = null;
            if (webView != null) webView.evaluateJavascript("if(window.onNativeScanCancelled){window.onNativeScanCancelled();}", null);
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        importExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (embeddedScanner != null && embeddedScanner.isActive()) {
            embeddedScanner.cancel();
            embeddedScanner = null;
            return;
        }
        if (webView != null) {
            webView.evaluateJavascript("(window.handleAndroidBack&&window.handleAndroidBack())?'handled':'not'", new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    if (!"\"handled\"".equals(value)) MainActivity.super.onBackPressed();
                }
            });
        } else {
            super.onBackPressed();
        }
    }

    public static class AppBridge {
        private static final Pattern ACCESS_KEY_PATTERN = Pattern.compile("(?<!\\d)(\\d{44})(?!\\d)");
        private static final Pattern NFSE_URL_KEY_PATTERN = Pattern.compile("(?:[?&]|\\b)chave=([^&#\\s]+)", Pattern.CASE_INSENSITIVE);
        private static final Pattern NFSE_50_PATTERN = Pattern.compile("(?<![0-9A-Za-z])([0-9A-Za-z]{50})(?![0-9A-Za-z])");
        private final DbHelper db;
        private final MainActivity activity;

        AppBridge(MainActivity activity) {
            this.activity = activity;
            db = new DbHelper(activity.getApplicationContext());
            try { repairLegacyRows(); } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void startScanner(int x, int y, int width, int height) {
            activity.iniciarScannerEmbutido(x, y, width, height);
        }

        @JavascriptInterface
        public void startFiscalConsultation(String key, String type, String rawUrl) {
            activity.iniciarConsultaFiscal(key, type, rawUrl);
        }

        @JavascriptInterface
        public void startImportPicker() {
            activity.iniciarImportacaoDocumento();
        }

        @JavascriptInterface
        public void openManualImportCrop() {
            activity.iniciarRecorteManualUltimoArquivo();
        }

        @JavascriptInterface
        public String getAppInfo() {
            try {
                JSONObject o = new JSONObject();
                o.put("name", "Controle Fiscal PCM");
                o.put("version", "0.4.9");
                o.put("package", activity.getPackageName());
                o.put("database", "SQLite local");
                o.put("scanner", "Câmera + importação rápida + OCR local de NFS-e + recorte manual");
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public String listNotes() {
            JSONArray arr = new JSONArray();
            try {
                SQLiteDatabase r = db.getReadableDatabase();
                String sql = "SELECT id,raw_code,chave_acesso,numero,fornecedor,cnpj,valor,emissao,escaneado_em,status,diagnostico,observacao,sincronizado,tipo_documento,modelo,serie,entregue_fiscal,entregue_fiscal_em FROM notas ORDER BY id DESC";
                try (Cursor c = r.rawQuery(sql, null)) {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("id", c.getLong(0));
                    o.put("raw", nz(c.getString(1)));
                    o.put("chave", nz(c.getString(2)));
                    o.put("numero", nz(c.getString(3)));
                    o.put("fornecedor", nz(c.getString(4)));
                    o.put("cnpj", nz(c.getString(5)));
                    o.put("valor", nz(c.getString(6)));
                    o.put("emissao", nz(c.getString(7)));
                    o.put("escaneadoEm", nz(c.getString(8)));
                    o.put("status", nz(c.getString(9)));
                    o.put("diagnostico", nz(c.getString(10)));
                    o.put("observacao", nz(c.getString(11)));
                    o.put("sincronizado", c.getInt(12) == 1);
                    o.put("tipoDocumento", nz(c.getString(13)));
                    o.put("modelo", nz(c.getString(14)));
                    o.put("serie", nz(c.getString(15)));
                    o.put("entregueFiscal", c.getInt(16) == 1);
                    o.put("entregueFiscalEm", nz(c.getString(17)));
                    arr.put(o);
                }
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        @JavascriptInterface
        public String analyzeScan(String raw) {
            try {
                FiscalScanData d = analyzeRaw(clean(raw));
                SQLiteDatabase r = db.getReadableDatabase();
                long duplicateId = findDuplicate(r, d.raw, d.key, d.numero, d.cnpj);
                JSONObject o = d.toJson();
                o.put("duplicate", duplicateId > 0);
                o.put("duplicateId", duplicateId);
                if (duplicateId > 0) {
                    repairLegacyRecord(duplicateId, d);
                    appendDuplicateInfo(db.getReadableDatabase(), duplicateId, o);
                }
                return o.toString();
            } catch (Exception e) {
                return result(false, "Falha ao interpretar leitura: " + e.getMessage(), -1, false);
            }
        }

        @JavascriptInterface
        public String saveNote(String raw, String numero, String fornecedor, String cnpj, String valor,
                               String emissao, String diagnostico, String tipoDocumento, String modelo, String serie,
                               String escaneadoEm) {
            try {
                raw = clean(raw);
                numero = clean(numero);
                fornecedor = clean(fornecedor);
                cnpj = clean(cnpj);
                valor = clean(valor);
                emissao = clean(emissao);
                diagnostico = clean(diagnostico);
                tipoDocumento = clean(tipoDocumento);
                modelo = clean(modelo);
                serie = clean(serie);
                escaneadoEm = clean(escaneadoEm);
                if (raw.isEmpty()) return result(false, "Escaneie ou informe a chave, QR Code ou código da nota.", -1, false);

                FiscalScanData parsed = analyzeRaw(raw);
                if (numero.isEmpty()) numero = parsed.numero;
                if (cnpj.isEmpty()) cnpj = parsed.cnpj;
                if (tipoDocumento.isEmpty()) tipoDocumento = parsed.tipoDocumento;
                if (modelo.isEmpty()) modelo = parsed.modelo;
                if (serie.isEmpty()) serie = parsed.serie;
                if (diagnostico.isEmpty()) diagnostico = parsed.diagnosticoSugerido;

                SQLiteDatabase w = db.getWritableDatabase();
                long duplicateId = findDuplicate(w, raw, parsed.key, numero, cnpj);
                if (duplicateId > 0) return result(false, "Possível duplicidade: esta nota já está registrada.", duplicateId, true);

                ContentValues v = new ContentValues();
                v.put("raw_code", raw);
                v.put("chave_acesso", parsed.key);
                v.put("numero", numero.isEmpty() ? "Não identificado" : numero);
                v.put("fornecedor", fornecedor.isEmpty() ? "Fornecedor não informado" : fornecedor);
                v.put("cnpj", cnpj);
                v.put("valor", valor);
                v.put("emissao", emissao);
                v.put("escaneado_em", escaneadoEm.isEmpty() ? now() : escaneadoEm);
                v.put("status", "PENDENTE");
                v.put("diagnostico", diagnostico.isEmpty() ? "ORDEM_SERVICO" : diagnostico);
                v.put("observacao", "");
                v.put("sincronizado", 0);
                v.put("tipo_documento", tipoDocumento.isEmpty() ? "Documento fiscal" : tipoDocumento);
                v.put("modelo", modelo);
                v.put("serie", serie);
                v.put("entregue_fiscal", 0);
                v.putNull("entregue_fiscal_em");
                long id = w.insertOrThrow("notas", null, v);
                return result(true, "Nota registrada localmente.", id, false);
            } catch (Exception e) {
                return result(false, "Falha ao registrar nota: " + e.getMessage(), -1, false);
            }
        }

        @JavascriptInterface
        public String updateAudit(long id, String status) {
            String s = clean(status);
            if (!("OK".equals(s) || "AGUARDANDO_RETORNO".equals(s) || "REPROVADA".equals(s) || "PENDENTE".equals(s))) {
                return result(false, "Status inválido.", id, false);
            }
            ContentValues v = new ContentValues();
            v.put("status", s);
            int n = db.getWritableDatabase().update("notas", v, "id=?", new String[]{String.valueOf(id)});
            return result(n == 1, n == 1 ? "Auditoria atualizada." : "Registro não encontrado.", id, false);
        }

        @JavascriptInterface
        public String updateDiagnosis(long id, String diagnosis) {
            ContentValues v = new ContentValues();
            v.put("diagnostico", clean(diagnosis));
            int n = db.getWritableDatabase().update("notas", v, "id=?", new String[]{String.valueOf(id)});
            return result(n == 1, n == 1 ? "Diagnóstico atualizado." : "Registro não encontrado.", id, false);
        }

        @JavascriptInterface
        public String updateObservation(long id, String observation) {
            ContentValues v = new ContentValues();
            v.put("observacao", clean(observation));
            int n = db.getWritableDatabase().update("notas", v, "id=?", new String[]{String.valueOf(id)});
            return result(n == 1, n == 1 ? "Observação salva." : "Registro não encontrado.", id, false);
        }

        @JavascriptInterface
        public String enrichExistingNote(long id, String fornecedor, String cnpj, String valor, String emissao,
                                         String diagnostico, String tipoDocumento, String modelo, String serie, String numero) {
            try {
                ContentValues v = new ContentValues();
                if (!clean(fornecedor).isEmpty()) v.put("fornecedor", clean(fornecedor));
                if (!clean(cnpj).isEmpty()) v.put("cnpj", clean(cnpj));
                if (!clean(valor).isEmpty()) v.put("valor", clean(valor));
                if (!clean(emissao).isEmpty()) v.put("emissao", clean(emissao));
                if (!clean(diagnostico).isEmpty()) v.put("diagnostico", clean(diagnostico));
                if (!clean(tipoDocumento).isEmpty()) v.put("tipo_documento", clean(tipoDocumento));
                if (!clean(modelo).isEmpty()) v.put("modelo", clean(modelo));
                if (!clean(serie).isEmpty()) v.put("serie", clean(serie));
                if (!clean(numero).isEmpty()) v.put("numero", clean(numero));
                if (v.size() == 0) return result(true, "Nenhum dado complementar novo.", id, true);
                int n = db.getWritableDatabase().update("notas", v, "id=?", new String[]{String.valueOf(id)});
                return result(n == 1, n == 1 ? "Registro existente atualizado com os dados recuperados." : "Registro não encontrado.", id, true);
            } catch (Exception e) {
                return result(false, "Falha ao atualizar registro existente: " + e.getMessage(), id, true);
            }
        }

        @JavascriptInterface
        public String markDelivered(String idsJson) {
            SQLiteDatabase w = db.getWritableDatabase();
            String timestamp = now();
            int updated = 0;
            try {
                JSONArray ids = new JSONArray(idsJson == null ? "[]" : idsJson);
                w.beginTransaction();
                for (int i = 0; i < ids.length(); i++) {
                    long id = ids.optLong(i, -1);
                    if (id <= 0) continue;
                    ContentValues v = new ContentValues();
                    v.put("entregue_fiscal", 1);
                    v.put("entregue_fiscal_em", timestamp);
                    int changed = w.update("notas", v, "id=? AND entregue_fiscal=0", new String[]{String.valueOf(id)});
                    if (changed == 1) {
                        updated++;
                        insertFiscalHistory(w, id, "ENTREGUE", "ENTREGA_FISCAL", "Entrega registrada ao fiscal", timestamp);
                    }
                }
                w.setTransactionSuccessful();
            } catch (Exception e) {
                return deliveryResult(false, "Falha ao registrar entrega: " + e.getMessage(), 0, "");
            } finally {
                if (w.inTransaction()) w.endTransaction();
            }
            return deliveryResult(true, updated + " nota(s) registrada(s) como entregue(s) ao fiscal.", updated, timestamp);
        }

        @JavascriptInterface
        public String returnFiscalPending(long id, String reasonCode, String observation) {
            String code = clean(reasonCode).toUpperCase(Locale.ROOT);
            String obs = clean(observation);
            String reason;
            if ("REGISTRO_INCORRETO".equals(code)) reason = "Entrega registrada por engano";
            else if ("DEVOLVIDA_FISCAL".equals(code)) reason = "Nota devolvida pelo fiscal";
            else if ("CORRECAO_PROCESSO".equals(code)) reason = "Correção/ajuste do controle fiscal";
            else if ("OUTRO".equals(code)) reason = obs.isEmpty() ? "Outro motivo informado pelo usuário" : obs;
            else return result(false, "Selecione o motivo do retorno para pendência.", id, false);

            if (!obs.isEmpty() && !"OUTRO".equals(code)) reason = reason + " — " + obs;
            SQLiteDatabase w = db.getWritableDatabase();
            String timestamp = now();
            try {
                w.beginTransaction();
                ContentValues v = new ContentValues();
                v.put("entregue_fiscal", 0);
                v.putNull("entregue_fiscal_em");
                int changed = w.update("notas", v, "id=? AND entregue_fiscal=1", new String[]{String.valueOf(id)});
                if (changed != 1) return result(false, "A nota não está marcada como entregue ao fiscal.", id, false);
                insertFiscalHistory(w, id, "RETORNO_PENDENCIA", code, reason, timestamp);
                w.setTransactionSuccessful();
                return result(true, "Nota devolvida para pendência de entrega ao fiscal.", id, false);
            } catch (Exception e) {
                return result(false, "Falha ao retornar nota para pendência: " + e.getMessage(), id, false);
            } finally {
                if (w.inTransaction()) w.endTransaction();
            }
        }

        @JavascriptInterface
        public String listFiscalHistory(long noteId) {
            JSONArray arr = new JSONArray();
            try {
                SQLiteDatabase r = db.getReadableDatabase();
                try (Cursor c = r.rawQuery("SELECT evento,motivo_codigo,motivo,data_hora FROM fiscal_historico WHERE nota_id=? ORDER BY id DESC", new String[]{String.valueOf(noteId)})) {
                    while (c.moveToNext()) {
                        JSONObject o = new JSONObject();
                        o.put("evento", nz(c.getString(0)));
                        o.put("motivoCodigo", nz(c.getString(1)));
                        o.put("motivo", nz(c.getString(2)));
                        o.put("dataHora", nz(c.getString(3)));
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        @JavascriptInterface
        public String deleteAllForTest() {
            SQLiteDatabase w = db.getWritableDatabase();
            int n = 0;
            try {
                w.beginTransaction();
                try { w.delete("fiscal_historico", null, null); } catch (Exception ignored) {}
                n = w.delete("notas", null, null);
                try { w.execSQL("DELETE FROM sqlite_sequence WHERE name IN ('notas','fiscal_historico')"); } catch (Exception ignored) {}
                w.setTransactionSuccessful();
                return result(true, n + " registro(s) removido(s). A base local foi limpa.", -1, false);
            } catch (Exception e) {
                return result(false, "Falha ao limpar os dados locais: " + e.getMessage(), -1, false);
            } finally {
                if (w.inTransaction()) w.endTransaction();
            }
        }

        private static void insertFiscalHistory(SQLiteDatabase db, long noteId, String event, String reasonCode, String reason, String timestamp) {
            ContentValues h = new ContentValues();
            h.put("nota_id", noteId);
            h.put("evento", clean(event));
            h.put("motivo_codigo", clean(reasonCode));
            h.put("motivo", clean(reason));
            h.put("data_hora", clean(timestamp));
            db.insertOrThrow("fiscal_historico", null, h);
        }

        private static FiscalScanData analyzeRaw(String raw) {
            FiscalScanData d = new FiscalScanData();
            d.raw = clean(raw);
            String nfe = extractAccessKey(d.raw);
            if (!nfe.isEmpty()) {
                d.key = nfe;
                d.keyValid = isValidNfeKey(nfe);
                d.numero = stripLeadingZeros(nfe.substring(25, 34));
                d.cnpj = formatCnpj(nfe.substring(6, 20));
                d.modelo = nfe.substring(20, 22);
                d.serie = stripLeadingZeros(nfe.substring(22, 25));
                d.ufCodigo = nfe.substring(0, 2);
                String aamm = nfe.substring(2, 6);
                d.periodo = aamm.substring(2, 4) + "/20" + aamm.substring(0, 2);
                d.tipoDocumento = "55".equals(d.modelo) ? "NF-e" : ("65".equals(d.modelo) ? "NFC-e" : "Documento fiscal");
                d.consultaTipo = "NFE";
                return d;
            }

            String nfse = extractNfseKey(d.raw);
            if (!nfse.isEmpty()) {
                d.key = nfse;
                d.keyValid = isPlausibleNfseKey(nfse);
                d.tipoDocumento = "NFS-e";
                d.modelo = "NFS-e";
                d.consultaTipo = "NFSE";
                d.diagnosticoSugerido = "ORDEM_SERVICO";
                if (nfse.length() == 50 && nfse.matches("\\d{50}")) {
                    String tif = nfse.substring(8, 9);
                    String inscricao = nfse.substring(9, 23);
                    if ("2".equals(tif)) d.cnpj = formatCnpj(inscricao);
                    else if ("1".equals(tif)) d.cnpj = formatCpf(inscricao.substring(Math.max(0, inscricao.length() - 11)));
                    d.numero = stripLeadingZeros(nfse.substring(23, 36));
                    String aamm = nfse.substring(36, 40);
                    if (aamm.matches("\\d{4}")) d.periodo = aamm.substring(2, 4) + "/20" + aamm.substring(0, 2);
                }
                return d;
            }

            String low = d.raw.toLowerCase(Locale.ROOT);
            if (low.startsWith("http://") || low.startsWith("https://")) {
                if (low.contains("nfse") || low.contains("nfs-e") || low.contains("servico")) {
                    d.tipoDocumento = "NFS-e";
                    d.modelo = "NFS-e";
                    d.consultaTipo = "NFSE";
                    d.diagnosticoSugerido = "ORDEM_SERVICO";
                } else d.tipoDocumento = "QR fiscal";
            }
            return d;
        }

        private static void appendDuplicateInfo(SQLiteDatabase db, long id, JSONObject o) {
            String sql = "SELECT numero,fornecedor,escaneado_em,status,diagnostico,tipo_documento FROM notas WHERE id=? LIMIT 1";
            try (Cursor c = db.rawQuery(sql, new String[]{String.valueOf(id)})) {
                if (c.moveToFirst()) {
                    o.put("duplicateNumero", nz(c.getString(0)));
                    o.put("duplicateFornecedor", nz(c.getString(1)));
                    o.put("duplicateEscaneadoEm", nz(c.getString(2)));
                    o.put("duplicateStatus", nz(c.getString(3)));
                    o.put("duplicateDiagnostico", nz(c.getString(4)));
                    o.put("duplicateTipoDocumento", nz(c.getString(5)));
                }
            } catch (Exception ignored) {}
        }

        private static long findDuplicate(SQLiteDatabase db, String raw, String key, String numero, String cnpj) {
            if (!clean(raw).isEmpty()) {
                try (Cursor c = db.rawQuery("SELECT id FROM notas WHERE raw_code=? LIMIT 1", new String[]{raw})) {
                    if (c.moveToFirst()) return c.getLong(0);
                }
            }
            if (!clean(key).isEmpty()) {
                try (Cursor c = db.rawQuery("SELECT id FROM notas WHERE chave_acesso=? OR raw_code LIKE ? LIMIT 1", new String[]{key, "%" + key + "%"})) {
                    if (c.moveToFirst()) return c.getLong(0);
                }
            }
            if (!clean(numero).isEmpty() && !clean(cnpj).isEmpty()) {
                try (Cursor c = db.rawQuery("SELECT id FROM notas WHERE numero=? AND REPLACE(REPLACE(REPLACE(cnpj,'.',''),'/',''),'-','')=? LIMIT 1", new String[]{numero, digitsOnly(cnpj)})) {
                    if (c.moveToFirst()) return c.getLong(0);
                }
            }
            return -1;
        }

        private void repairLegacyRows() {
            SQLiteDatabase r = db.getReadableDatabase();
            java.util.ArrayList<Long> ids = new java.util.ArrayList<>();
            java.util.ArrayList<FiscalScanData> parsed = new java.util.ArrayList<>();
            try (Cursor c = r.rawQuery("SELECT id,raw_code,numero,cnpj,tipo_documento FROM notas", null)) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    FiscalScanData d = analyzeRaw(nz(c.getString(1)));
                    if (d.key.isEmpty()) continue;
                    String oldNumero = nz(c.getString(2));
                    String oldCnpj = nz(c.getString(3));
                    String oldTipo = nz(c.getString(4));
                    if (oldNumero.isEmpty() || "Não identificado".equalsIgnoreCase(oldNumero) || oldCnpj.isEmpty() || oldTipo.isEmpty() || "Documento fiscal".equals(oldTipo)) {
                        ids.add(id);
                        parsed.add(d);
                    }
                }
            } catch (Exception ignored) {}
            SQLiteDatabase w = db.getWritableDatabase();
            for (int i = 0; i < ids.size(); i++) repairLegacyRecord(ids.get(i), parsed.get(i));
        }

        private void repairLegacyRecord(long id, FiscalScanData d) {
            if (id <= 0 || d == null || d.key.isEmpty()) return;
            try {
                ContentValues v = new ContentValues();
                v.put("chave_acesso", d.key);
                if (!d.numero.isEmpty()) v.put("numero", d.numero);
                if (!d.cnpj.isEmpty()) v.put("cnpj", d.cnpj);
                if (!d.tipoDocumento.isEmpty()) v.put("tipo_documento", d.tipoDocumento);
                if (!d.modelo.isEmpty()) v.put("modelo", d.modelo);
                if (!d.serie.isEmpty()) v.put("serie", d.serie);
                if ("NFS-e".equals(d.tipoDocumento)) v.put("diagnostico", "ORDEM_SERVICO");
                db.getWritableDatabase().update("notas", v, "id=?", new String[]{String.valueOf(id)});
            } catch (Exception ignored) {}
        }

        private static String extractAccessKey(String raw) {
            if (raw == null || raw.isEmpty()) return "";
            Matcher m = ACCESS_KEY_PATTERN.matcher(raw);
            while (m.find()) {
                String candidate = m.group(1);
                if (isValidNfeKey(candidate)) return candidate;
            }
            String digits = digitsOnly(raw);
            if (digits.length() == 44 && isValidNfeKey(digits)) return digits;
            if (digits.length() > 44) {
                for (int i = 0; i + 44 <= digits.length(); i++) {
                    String candidate = digits.substring(i, i + 44);
                    if (isValidNfeKey(candidate) && ("55".equals(candidate.substring(20, 22)) || "65".equals(candidate.substring(20, 22)))) return candidate;
                }
            }
            return "";
        }

        private static String extractNfseKey(String raw) {
            if (raw == null || raw.isEmpty()) return "";
            String decoded = raw;
            try { decoded = URLDecoder.decode(raw, "UTF-8"); } catch (Exception ignored) {}
            Matcher url = NFSE_URL_KEY_PATTERN.matcher(decoded);
            if (url.find()) {
                String candidate = url.group(1).replaceAll("[^0-9A-Za-z]", "");
                if (candidate.length() >= 50) {
                    candidate = candidate.substring(0, 50);
                    if (isPlausibleNfseKey(candidate)) return candidate;
                }
            }
            Matcher generic = NFSE_50_PATTERN.matcher(decoded);
            while (generic.find()) {
                String c = generic.group(1);
                if (isPlausibleNfseKey(c)) return c;
            }
            String compact = decoded.replaceAll("[^0-9A-Za-z]", "");
            if (compact.length() == 50 && isPlausibleNfseKey(compact)) return compact;
            return "";
        }

        private static boolean isPlausibleNfseKey(String key) {
            if (key == null || key.length() != 50) return false;
            if (!key.matches("[0-9A-Za-z]{50}")) return false;
            if (key.matches("\\d{50}")) {
                String env = key.substring(7, 8);
                String tif = key.substring(8, 9);
                String aamm = key.substring(36, 40);
                if (!("1".equals(env) || "2".equals(env))) return false;
                if (!("1".equals(tif) || "2".equals(tif))) return false;
                if (aamm.matches("\\d{4}")) {
                    int mm;
                    try { mm = Integer.parseInt(aamm.substring(2, 4)); } catch (Exception e) { return false; }
                    return mm >= 1 && mm <= 12;
                }
            }
            return true;
        }

        private static boolean isValidNfeKey(String key) {
            if (key == null || key.length() != 44 || !key.matches("\\d{44}")) return false;
            int sum = 0, weight = 2;
            for (int i = 42; i >= 0; i--) {
                sum += Character.digit(key.charAt(i), 10) * weight;
                if (++weight > 9) weight = 2;
            }
            int dv = 11 - (sum % 11);
            if (dv == 10 || dv == 11) dv = 0;
            return dv == Character.digit(key.charAt(43), 10);
        }

        private static String formatCnpj(String digits) {
            String d = digitsOnly(digits);
            if (d.length() != 14) return digits == null ? "" : digits;
            return d.substring(0,2)+"."+d.substring(2,5)+"."+d.substring(5,8)+"/"+d.substring(8,12)+"-"+d.substring(12,14);
        }

        private static String formatCpf(String digits) {
            String d = digitsOnly(digits);
            if (d.length() != 11) return digits == null ? "" : digits;
            return d.substring(0,3)+"."+d.substring(3,6)+"."+d.substring(6,9)+"-"+d.substring(9,11);
        }

        private static String stripLeadingZeros(String value) {
            String v = value == null ? "" : value.replaceFirst("^0+(?!$)", "");
            return v.isEmpty() ? "0" : v;
        }
        private static String digitsOnly(String s) { return s == null ? "" : s.replaceAll("\\D", ""); }
        private static String clean(String s) { return s == null ? "" : s.trim(); }
        private static String nz(String s) { return s == null ? "" : s; }
        private static String now() { return new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR")).format(new Date()); }

        private static String result(boolean ok, String message, long id, boolean duplicate) {
            try {
                JSONObject o = new JSONObject();
                o.put("ok", ok); o.put("message", message); o.put("id", id); o.put("duplicate", duplicate);
                return o.toString();
            } catch (Exception e) { return "{\"ok\":false}"; }
        }

        private static String deliveryResult(boolean ok, String message, int count, String timestamp) {
            try {
                JSONObject o = new JSONObject();
                o.put("ok", ok); o.put("message", message); o.put("count", count); o.put("timestamp", timestamp);
                return o.toString();
            } catch (Exception e) { return "{\"ok\":false}"; }
        }

        private static final class FiscalScanData {
            String raw="", key="", numero="", cnpj="", periodo="", modelo="", serie="", ufCodigo="";
            String tipoDocumento="Documento fiscal", consultaTipo="", diagnosticoSugerido="";
            boolean keyValid=false;
            JSONObject toJson() throws Exception {
                JSONObject o = new JSONObject();
                o.put("ok", true); o.put("raw", raw); o.put("chave", key); o.put("chaveValida", keyValid);
                o.put("numero", numero); o.put("cnpj", cnpj); o.put("periodoEmissao", periodo);
                o.put("modelo", modelo); o.put("serie", serie); o.put("ufCodigo", ufCodigo);
                o.put("tipoDocumento", tipoDocumento); o.put("consultaTipo", consultaTipo);
                o.put("diagnosticoSugerido", diagnosticoSugerido);
                return o;
            }
        }
    }

    private static class DbHelper extends SQLiteOpenHelper {
        private static final String DB_NAME = "controle_fiscal_pcm.db";
        private static final int DB_VERSION = 4;
        DbHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE notas (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "raw_code TEXT NOT NULL UNIQUE," +
                    "chave_acesso TEXT," +
                    "numero TEXT," +
                    "fornecedor TEXT," +
                    "cnpj TEXT," +
                    "valor TEXT," +
                    "emissao TEXT," +
                    "escaneado_em TEXT NOT NULL," +
                    "status TEXT NOT NULL DEFAULT 'PENDENTE'," +
                    "diagnostico TEXT NOT NULL DEFAULT 'ORDEM_SERVICO'," +
                    "observacao TEXT," +
                    "sincronizado INTEGER NOT NULL DEFAULT 0," +
                    "pcm_id TEXT," +
                    "status_pre_avaliacao_pcm TEXT," +
                    "resultado_pre_avaliacao TEXT," +
                    "data_sincronizacao TEXT," +
                    "erro_sincronizacao TEXT," +
                    "tipo_documento TEXT NOT NULL DEFAULT 'Documento fiscal'," +
                    "modelo TEXT," +
                    "serie TEXT," +
                    "entregue_fiscal INTEGER NOT NULL DEFAULT 0," +
                    "entregue_fiscal_em TEXT" +
                    ")");
            db.execSQL("CREATE INDEX idx_notas_chave ON notas(chave_acesso)");
            db.execSQL("CREATE INDEX idx_notas_numero_cnpj ON notas(numero,cnpj)");
            db.execSQL("CREATE INDEX idx_notas_status ON notas(status)");
            db.execSQL("CREATE INDEX idx_notas_entregue_fiscal ON notas(entregue_fiscal)");
            db.execSQL("CREATE TABLE fiscal_historico (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "nota_id INTEGER NOT NULL," +
                    "evento TEXT NOT NULL," +
                    "motivo_codigo TEXT," +
                    "motivo TEXT," +
                    "data_hora TEXT NOT NULL" +
                    ")");
            db.execSQL("CREATE INDEX idx_fiscal_historico_nota ON fiscal_historico(nota_id,id)");
        }

        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if (oldVersion < 2) {
                try { db.execSQL("ALTER TABLE notas ADD COLUMN chave_acesso TEXT"); } catch (Exception ignored) {}
                try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_notas_chave ON notas(chave_acesso)"); } catch (Exception ignored) {}
            }
            if (oldVersion < 3) {
                try { db.execSQL("ALTER TABLE notas ADD COLUMN tipo_documento TEXT NOT NULL DEFAULT 'Documento fiscal'"); } catch (Exception ignored) {}
                try { db.execSQL("ALTER TABLE notas ADD COLUMN modelo TEXT"); } catch (Exception ignored) {}
                try { db.execSQL("ALTER TABLE notas ADD COLUMN serie TEXT"); } catch (Exception ignored) {}
                try { db.execSQL("ALTER TABLE notas ADD COLUMN entregue_fiscal INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
                try { db.execSQL("ALTER TABLE notas ADD COLUMN entregue_fiscal_em TEXT"); } catch (Exception ignored) {}
                try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_notas_entregue_fiscal ON notas(entregue_fiscal)"); } catch (Exception ignored) {}
            }
            if (oldVersion < 4) {
                try { db.execSQL("CREATE TABLE IF NOT EXISTS fiscal_historico (id INTEGER PRIMARY KEY AUTOINCREMENT,nota_id INTEGER NOT NULL,evento TEXT NOT NULL,motivo_codigo TEXT,motivo TEXT,data_hora TEXT NOT NULL)"); } catch (Exception ignored) {}
                try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_fiscal_historico_nota ON fiscal_historico(nota_id,id)"); } catch (Exception ignored) {}
                try { db.execSQL("INSERT INTO fiscal_historico(nota_id,evento,motivo_codigo,motivo,data_hora) SELECT id,'ENTREGUE','MIGRADO','Entrega já registrada antes da V0.4.8',entregue_fiscal_em FROM notas WHERE entregue_fiscal=1 AND entregue_fiscal_em IS NOT NULL AND entregue_fiscal_em<>''"); } catch (Exception ignored) {}
            }
        }
    }
}
